insert into cookshoong_shop_dev.cart_detail_menu_options (cart_detail_id, option_id)
values  (357, 1),
        (357, 31);