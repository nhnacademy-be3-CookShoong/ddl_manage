insert into cookshoong_shop_dev.review (review_id, order_code, contents, rating, written_at, updated_at)
values  (27, 0x971B85948AA941AC8AFEB6A78C5A0C67, '<p>5점 리뷰</p>', 5, '2023-08-16 14:49:59', null),
        (28, 0x5EA4DE5ADB134C04AF7EB42E00E5960B, '<p>1점 리뷰</p>', 1, '2023-08-16 14:50:45', null),
        (29, 0x904B121D2B274C94A22210DCB98B321E, '<p>4점 리뷰</p>', 5, '2023-08-16 14:51:55', null),
        (30, 0x2DE30AE047CA48DA8B95950585BA12E2, '<p>너무 맛있게 잘 먹었습니다!!!</p>', 5, '2023-08-22 15:24:05', null),
        (31, 0xB1446E71438D469AA8D73BB04E89EC9D, '<p>이모~~ 여기 소주한병이요~ 를 외치게 만드는 국밥의 맛.</p>', 5, '2023-08-27 14:14:28', '2023-08-27 14:14:54');