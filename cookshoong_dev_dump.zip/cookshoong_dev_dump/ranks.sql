insert into cookshoong_shop_dev.ranks (rank_code, name)
values  ('LEVEL_1', '프랜드'),
        ('LEVEL_2', '패밀리'),
        ('LEVEL_3', '마스터'),
        ('LEVEL_4', 'VIP마스터');