insert into cookshoong_shop_dev.word_dict (word_id, word_text)
values  (1, '피자'),
        (2, '파이'),
        (3, '알리올리오'),
        (4, '시카고'),
        (5, '알볼로'),
        (6, '스파게티'),
        (7, '파스타'),
        (8, '국수'),
        (9, '라면'),
        (10, '쫄면');