insert into cookshoong_shop_dev.bank_types (bank_type_code, description)
values  ('HANA', '하나은행'),
        ('IBK', 'IBK기업은행'),
        ('KB', '국민은행'),
        ('KG', '광주은행'),
        ('SHIN', '신한은행'),
        ('SMG', '새만금은행');