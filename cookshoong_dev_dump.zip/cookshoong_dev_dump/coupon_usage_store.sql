insert into cookshoong_shop_dev.coupon_usage_store (coupon_usage_id, store_id)
values  (2, 1),
        (3, 2),
        (4, 3);