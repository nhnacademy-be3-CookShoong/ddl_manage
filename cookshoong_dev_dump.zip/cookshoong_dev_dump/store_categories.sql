insert into cookshoong_shop_dev.store_categories (category_code, description)
values  ('BOX', '도시락'),
        ('BUN', '분식'),
        ('CHK', '치킨'),
        ('CHN', '중식'),
        ('DES', '디저트'),
        ('JPN', '일식'),
        ('KOR', '한식'),
        ('NIG', '야식'),
        ('PIZ', '피자'),
        ('POR', '양식');