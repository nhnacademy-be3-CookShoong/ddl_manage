insert into cookshoong_shop_dev.account_status (status_code, description)
values  ('ACTIVE', '활성'),
        ('DORMANCY', '휴면'),
        ('WITHDRAWAL', '탈퇴');