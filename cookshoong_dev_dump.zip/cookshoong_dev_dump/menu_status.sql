insert into cookshoong_shop_dev.menu_status (menu_status_code, description)
values  ('CLOSE', '준비중'),
        ('OPEN', '판매중'),
        ('OUTED', '삭제됨');