insert into cookshoong_shop_dev.refund_types (refund_type_code, name, is_deleted)
values  ('admin', 'asas', 1),
        ('FULL', '전액환불', 0),
        ('PARTIAL', '부분환불', 0),
        ('SUB', '마이너스환불', 1),
        ('test', 'test', 1);