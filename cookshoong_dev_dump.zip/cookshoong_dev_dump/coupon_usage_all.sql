insert into cookshoong_shop_dev.coupon_usage_all (coupon_usage_id)
values  (1);