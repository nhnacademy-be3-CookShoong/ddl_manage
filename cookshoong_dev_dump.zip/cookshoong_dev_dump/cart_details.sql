insert into cookshoong_shop_dev.cart_details (cart_detail_id, cart_id, menu_id, count, created_time_millis)
values  (357, 0x509EDD45F3F04F5A9025B6B74A449B67, 26, 1, 1693054663516),
        (358, 0x509EDD45F3F04F5A9025B6B74A449B67, 28, 1, 1693054671157);