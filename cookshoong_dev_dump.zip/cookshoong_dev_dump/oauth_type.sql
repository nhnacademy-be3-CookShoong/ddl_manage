insert into cookshoong_shop_dev.oauth_type (oauth_type_id, provider)
values  (1, 'payco'),
        (2, 'naver'),
        (3, 'google'),
        (4, 'github'),
        (5, 'facebook'),
        (6, 'kakao');