insert into cookshoong_shop_prod.coupon_log_type (coupon_log_type_code, description)
values  ('REFUND', '환불'),
        ('USE', '사용');