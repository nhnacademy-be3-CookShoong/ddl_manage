insert into cookshoong_shop_prod.BATCH_STEP_EXECUTION (STEP_EXECUTION_ID, VERSION, STEP_NAME, JOB_EXECUTION_ID, START_TIME, END_TIME, STATUS, COMMIT_COUNT, READ_COUNT, FILTER_COUNT, WRITE_COUNT, READ_SKIP_COUNT, WRITE_SKIP_COUNT, PROCESS_SKIP_COUNT, ROLLBACK_COUNT, EXIT_CODE, EXIT_MESSAGE, LAST_UPDATED)
values  (1, 4, '생일 쿠폰 정보 가져오기', 1, '2023-08-23 13:55:00.630000', '2023-08-23 13:55:00.948000', 'COMPLETED', 2, 1, 0, 1, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-23 13:55:00.963000'),
        (2, 4, '생일쿠폰 발급', 1, '2023-08-23 13:55:01.229000', '2023-08-23 13:55:01.543000', 'COMPLETED', 2, 10, 0, 10, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-23 13:55:01.558000'),
        (3, 4, '생일 쿠폰 정보 가져오기', 2, '2023-08-23 14:03:00.769000', '2023-08-23 14:03:01.113000', 'COMPLETED', 2, 1, 0, 1, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-23 14:03:01.129000'),
        (4, 4, '생일쿠폰 발급', 2, '2023-08-23 14:03:01.401000', '2023-08-23 14:03:01.696000', 'COMPLETED', 2, 10, 0, 10, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-23 14:03:01.711000'),
        (5, 4, '생일 쿠폰 정보 가져오기', 3, '2023-08-23 14:12:00.636000', '2023-08-23 14:12:00.925000', 'COMPLETED', 2, 1, 0, 1, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-23 14:12:00.941000'),
        (6, 4, '생일쿠폰 발급', 3, '2023-08-23 14:12:01.217000', '2023-08-23 14:12:01.604000', 'COMPLETED', 2, 10, 0, 10, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-23 14:12:01.621000'),
        (7, 4, '생일 쿠폰 정보 가져오기', 16, '2023-08-23 14:25:00.721000', '2023-08-23 14:25:01.070000', 'COMPLETED', 2, 1, 0, 1, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-23 14:25:01.088000'),
        (8, 4, '생일쿠폰 발급', 16, '2023-08-23 14:25:01.370000', '2023-08-23 14:25:01.682000', 'COMPLETED', 2, 10, 0, 10, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-23 14:25:01.698000'),
        (9, 4, '생일 쿠폰 정보 가져오기', 17, '2023-08-23 14:26:00.586000', '2023-08-23 14:26:00.885000', 'COMPLETED', 2, 1, 0, 1, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-23 14:26:00.902000'),
        (10, 4, '생일쿠폰 발급', 17, '2023-08-23 14:26:01.201000', '2023-08-23 14:26:01.501000', 'COMPLETED', 2, 10, 0, 10, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-23 14:26:01.517000'),
        (11, 3, '등급 이름들 가져오기', 18, '2023-08-23 14:34:00.663000', '2023-08-23 14:34:00.908000', 'COMPLETED', 1, 4, 0, 4, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-23 14:34:00.924000'),
        (12, 6, '등급 재산정', 18, '2023-08-23 14:34:01.211000', '2023-08-23 14:34:01.906000', 'COMPLETED', 4, 33, 0, 33, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-23 14:34:01.922000'),
        (13, 3, '등급 이름들 가져오기', 19, '2023-08-23 14:36:00.661000', '2023-08-23 14:36:00.888000', 'COMPLETED', 1, 4, 0, 4, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-23 14:36:00.904000'),
        (14, 6, '등급 재산정', 19, '2023-08-23 14:36:01.169000', '2023-08-23 14:36:01.840000', 'COMPLETED', 4, 33, 0, 33, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-23 14:36:01.855000'),
        (15, 3, '등급 이름들 가져오기', 21, '2023-08-23 14:39:00.631000', '2023-08-23 14:39:00.869000', 'COMPLETED', 1, 4, 0, 4, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-23 14:39:00.883000'),
        (16, 6, '등급 재산정', 21, '2023-08-23 14:39:01.132000', '2023-08-23 14:39:01.762000', 'COMPLETED', 4, 33, 0, 33, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-23 14:39:01.777000'),
        (17, 3, '등급 이름들 가져오기', 22, '2023-08-23 14:40:00.522000', '2023-08-23 14:40:00.730000', 'COMPLETED', 1, 4, 0, 4, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-23 14:40:00.744000'),
        (18, 6, '등급 재산정', 22, '2023-08-23 14:40:01.027000', '2023-08-23 14:40:01.656000', 'COMPLETED', 4, 33, 0, 33, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-23 14:40:01.670000'),
        (19, 3, '생일 쿠폰 정보 가져오기', 23, '2023-08-24 13:02:52.081000', '2023-08-24 13:02:52.297000', 'COMPLETED', 1, 0, 0, 0, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-24 13:02:52.311000'),
        (20, 2, '생일쿠폰 발급', 23, '2023-08-24 13:02:52.563000', '2023-08-24 13:02:52.788000', 'FAILED', 0, 10, 0, 0, 0, 0, 0, 2, 'FAILED', 'org.springframework.retry.RetryException: Non-skippable exception in recoverer while processing; nested exception is java.lang.NullPointerException
	at org.springframework.batch.core.step.item.FaultTolerantChunkProcessor$2.recover(FaultTolerantChunkProcessor.java:299)
	at org.springframework.retry.support.RetryTemplate.handleRetryExhausted(RetryTemplate.java:539)
	at org.springframework.retry.support.RetryTemplate.doExecute(RetryTemplate.java:387)
	at org.springframework.retry.support.RetryTemplate.execute(RetryTemplate.java:255)
	at org.springframework.batch.core.step.item.BatchRetryTemplate.execute(BatchRetryTemplate.java:217)
	at org.springframework.batch.core.step.item.FaultTolerantChunkProcessor.transform(FaultTolerantChunkProcessor.java:308)
	at org.springframework.batch.core.step.item.SimpleChunkProcessor.process(SimpleChunkProcessor.java:210)
	at org.springframework.batch.core.step.item.ChunkOrientedTasklet.execute(ChunkOrientedTasklet.java:77)
	at org.springframework.batch.core.step.tasklet.TaskletStep$ChunkTransactionCallback.doInTransaction(TaskletStep.java:407)
	at org.springframework.batch.core.step.tasklet.TaskletStep$ChunkTransactionCallback.doInTransaction(TaskletStep.java:331)
	at org.springframework.transaction.support.TransactionTemplate.execute(TransactionTemplate.java:140)
	at org.springframework.batch.core.step.tasklet.TaskletStep$2.doInChunkContext(TaskletStep.java:273)
	at org.springframework.batch.core.scope.context.StepContextRepeatCallback.doInIteration(StepContextRepeatCallback.java:82)
	at org.springframework.batch.repeat.support.RepeatTemplate.getNextResult(RepeatTemplate.java:375)
	at org.springframework.batch.repeat.support.RepeatTemplate.executeInternal(RepeatTemplate.java:215)
	at org.springframework.batch.repeat.support.RepeatTemplate.iterate(RepeatTemplate.java:145)
	at org.springframework.batch.core.step.tasklet.TaskletStep.doExecute(TaskletStep.java:258)
	at org.springframework.batch.core.step.AbstractStep.execute(AbstractStep.java:208)
	at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at java.base/jdk.internal.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.base/java.lang.reflect.Method.invoke(Method.java:566)
	at org.springframework.aop.support.AopUtils.invokeJoinpointUsingReflection(AopUtils.java:344)
	at org.springframework.aop.framework.Re', '2023-08-24 13:02:52.802000'),
        (21, 3, '등급 이름들 가져오기', 24, '2023-08-24 13:02:53.423000', '2023-08-24 13:02:53.636000', 'COMPLETED', 1, 4, 0, 4, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-24 13:02:53.651000'),
        (22, 6, '등급 재산정', 24, '2023-08-24 13:02:53.895000', '2023-08-24 13:02:54.551000', 'COMPLETED', 4, 38, 0, 38, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-24 13:02:54.565000'),
        (23, 3, '휴면될 회원리스트 가져오기', 25, '2023-08-24 13:02:55.221000', '2023-08-24 13:02:55.430000', 'COMPLETED', 1, 0, 0, 0, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-24 13:02:55.445000'),
        (24, 3, '생일 쿠폰 정보 가져오기', 26, '2023-08-24 13:05:08.208000', '2023-08-24 13:05:08.447000', 'COMPLETED', 1, 0, 0, 0, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-24 13:05:08.463000'),
        (25, 2, '생일쿠폰 발급', 26, '2023-08-24 13:05:08.719000', '2023-08-24 13:05:08.940000', 'FAILED', 0, 10, 0, 0, 0, 0, 0, 2, 'FAILED', 'org.springframework.retry.RetryException: Non-skippable exception in recoverer while processing; nested exception is java.lang.NullPointerException
	at org.springframework.batch.core.step.item.FaultTolerantChunkProcessor$2.recover(FaultTolerantChunkProcessor.java:299)
	at org.springframework.retry.support.RetryTemplate.handleRetryExhausted(RetryTemplate.java:539)
	at org.springframework.retry.support.RetryTemplate.doExecute(RetryTemplate.java:387)
	at org.springframework.retry.support.RetryTemplate.execute(RetryTemplate.java:255)
	at org.springframework.batch.core.step.item.BatchRetryTemplate.execute(BatchRetryTemplate.java:217)
	at org.springframework.batch.core.step.item.FaultTolerantChunkProcessor.transform(FaultTolerantChunkProcessor.java:308)
	at org.springframework.batch.core.step.item.SimpleChunkProcessor.process(SimpleChunkProcessor.java:210)
	at org.springframework.batch.core.step.item.ChunkOrientedTasklet.execute(ChunkOrientedTasklet.java:77)
	at org.springframework.batch.core.step.tasklet.TaskletStep$ChunkTransactionCallback.doInTransaction(TaskletStep.java:407)
	at org.springframework.batch.core.step.tasklet.TaskletStep$ChunkTransactionCallback.doInTransaction(TaskletStep.java:331)
	at org.springframework.transaction.support.TransactionTemplate.execute(TransactionTemplate.java:140)
	at org.springframework.batch.core.step.tasklet.TaskletStep$2.doInChunkContext(TaskletStep.java:273)
	at org.springframework.batch.core.scope.context.StepContextRepeatCallback.doInIteration(StepContextRepeatCallback.java:82)
	at org.springframework.batch.repeat.support.RepeatTemplate.getNextResult(RepeatTemplate.java:375)
	at org.springframework.batch.repeat.support.RepeatTemplate.executeInternal(RepeatTemplate.java:215)
	at org.springframework.batch.repeat.support.RepeatTemplate.iterate(RepeatTemplate.java:145)
	at org.springframework.batch.core.step.tasklet.TaskletStep.doExecute(TaskletStep.java:258)
	at org.springframework.batch.core.step.AbstractStep.execute(AbstractStep.java:208)
	at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at java.base/jdk.internal.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.base/java.lang.reflect.Method.invoke(Method.java:566)
	at org.springframework.aop.support.AopUtils.invokeJoinpointUsingReflection(AopUtils.java:344)
	at org.springframework.aop.framework.Re', '2023-08-24 13:05:08.954000'),
        (26, 3, '등급 이름들 가져오기', 27, '2023-08-24 13:05:09.615000', '2023-08-24 13:05:09.820000', 'COMPLETED', 1, 4, 0, 4, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-24 13:05:09.834000'),
        (27, 6, '등급 재산정', 27, '2023-08-24 13:05:10.086000', '2023-08-24 13:05:10.726000', 'COMPLETED', 4, 38, 0, 38, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-24 13:05:10.741000'),
        (28, 3, '생일 쿠폰 정보 가져오기', 29, '2023-08-26 15:09:07.851000', '2023-08-26 15:09:08.090000', 'COMPLETED', 1, 0, 0, 0, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-26 15:09:08.106000'),
        (29, 2, '생일쿠폰 발급', 29, '2023-08-26 15:09:08.364000', '2023-08-26 15:09:08.580000', 'FAILED', 0, 10, 0, 0, 0, 0, 0, 2, 'FAILED', 'org.springframework.retry.RetryException: Non-skippable exception in recoverer while processing; nested exception is java.lang.NullPointerException
	at org.springframework.batch.core.step.item.FaultTolerantChunkProcessor$2.recover(FaultTolerantChunkProcessor.java:299)
	at org.springframework.retry.support.RetryTemplate.handleRetryExhausted(RetryTemplate.java:539)
	at org.springframework.retry.support.RetryTemplate.doExecute(RetryTemplate.java:387)
	at org.springframework.retry.support.RetryTemplate.execute(RetryTemplate.java:255)
	at org.springframework.batch.core.step.item.BatchRetryTemplate.execute(BatchRetryTemplate.java:217)
	at org.springframework.batch.core.step.item.FaultTolerantChunkProcessor.transform(FaultTolerantChunkProcessor.java:308)
	at org.springframework.batch.core.step.item.SimpleChunkProcessor.process(SimpleChunkProcessor.java:210)
	at org.springframework.batch.core.step.item.ChunkOrientedTasklet.execute(ChunkOrientedTasklet.java:77)
	at org.springframework.batch.core.step.tasklet.TaskletStep$ChunkTransactionCallback.doInTransaction(TaskletStep.java:407)
	at org.springframework.batch.core.step.tasklet.TaskletStep$ChunkTransactionCallback.doInTransaction(TaskletStep.java:331)
	at org.springframework.transaction.support.TransactionTemplate.execute(TransactionTemplate.java:140)
	at org.springframework.batch.core.step.tasklet.TaskletStep$2.doInChunkContext(TaskletStep.java:273)
	at org.springframework.batch.core.scope.context.StepContextRepeatCallback.doInIteration(StepContextRepeatCallback.java:82)
	at org.springframework.batch.repeat.support.RepeatTemplate.getNextResult(RepeatTemplate.java:375)
	at org.springframework.batch.repeat.support.RepeatTemplate.executeInternal(RepeatTemplate.java:215)
	at org.springframework.batch.repeat.support.RepeatTemplate.iterate(RepeatTemplate.java:145)
	at org.springframework.batch.core.step.tasklet.TaskletStep.doExecute(TaskletStep.java:258)
	at org.springframework.batch.core.step.AbstractStep.execute(AbstractStep.java:208)
	at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at java.base/jdk.internal.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.base/java.lang.reflect.Method.invoke(Method.java:566)
	at org.springframework.aop.support.AopUtils.invokeJoinpointUsingReflection(AopUtils.java:344)
	at org.springframework.aop.framework.Re', '2023-08-26 15:09:08.596000'),
        (30, 3, '등급 이름들 가져오기', 30, '2023-08-26 15:09:09.254000', '2023-08-26 15:09:09.461000', 'COMPLETED', 1, 4, 0, 4, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-26 15:09:09.475000'),
        (31, 6, '등급 재산정', 30, '2023-08-26 15:09:09.721000', '2023-08-26 15:09:10.360000', 'COMPLETED', 4, 38, 0, 38, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-26 15:09:10.374000'),
        (32, 3, '휴면될 회원리스트 가져오기', 31, '2023-08-26 15:09:11.068000', '2023-08-26 15:09:11.260000', 'COMPLETED', 1, 0, 0, 0, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-26 15:09:11.275000'),
        (33, 3, 'statusChangeFailStep', 31, '2023-08-26 15:09:11.558000', '2023-08-26 15:09:12.851000', 'COMPLETED', 1, 0, 0, 0, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-26 15:09:12.865000'),
        (34, 3, '생일 쿠폰 정보 가져오기', 32, '2023-08-26 15:11:17.675000', '2023-08-26 15:11:17.940000', 'COMPLETED', 1, 0, 0, 0, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-26 15:11:17.959000'),
        (35, 2, '생일쿠폰 발급', 32, '2023-08-26 15:11:18.240000', '2023-08-26 15:11:18.462000', 'FAILED', 0, 10, 0, 0, 0, 0, 0, 2, 'FAILED', 'org.springframework.retry.RetryException: Non-skippable exception in recoverer while processing; nested exception is java.lang.NullPointerException
	at org.springframework.batch.core.step.item.FaultTolerantChunkProcessor$2.recover(FaultTolerantChunkProcessor.java:299)
	at org.springframework.retry.support.RetryTemplate.handleRetryExhausted(RetryTemplate.java:539)
	at org.springframework.retry.support.RetryTemplate.doExecute(RetryTemplate.java:387)
	at org.springframework.retry.support.RetryTemplate.execute(RetryTemplate.java:255)
	at org.springframework.batch.core.step.item.BatchRetryTemplate.execute(BatchRetryTemplate.java:217)
	at org.springframework.batch.core.step.item.FaultTolerantChunkProcessor.transform(FaultTolerantChunkProcessor.java:308)
	at org.springframework.batch.core.step.item.SimpleChunkProcessor.process(SimpleChunkProcessor.java:210)
	at org.springframework.batch.core.step.item.ChunkOrientedTasklet.execute(ChunkOrientedTasklet.java:77)
	at org.springframework.batch.core.step.tasklet.TaskletStep$ChunkTransactionCallback.doInTransaction(TaskletStep.java:407)
	at org.springframework.batch.core.step.tasklet.TaskletStep$ChunkTransactionCallback.doInTransaction(TaskletStep.java:331)
	at org.springframework.transaction.support.TransactionTemplate.execute(TransactionTemplate.java:140)
	at org.springframework.batch.core.step.tasklet.TaskletStep$2.doInChunkContext(TaskletStep.java:273)
	at org.springframework.batch.core.scope.context.StepContextRepeatCallback.doInIteration(StepContextRepeatCallback.java:82)
	at org.springframework.batch.repeat.support.RepeatTemplate.getNextResult(RepeatTemplate.java:375)
	at org.springframework.batch.repeat.support.RepeatTemplate.executeInternal(RepeatTemplate.java:215)
	at org.springframework.batch.repeat.support.RepeatTemplate.iterate(RepeatTemplate.java:145)
	at org.springframework.batch.core.step.tasklet.TaskletStep.doExecute(TaskletStep.java:258)
	at org.springframework.batch.core.step.AbstractStep.execute(AbstractStep.java:208)
	at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at java.base/jdk.internal.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.base/java.lang.reflect.Method.invoke(Method.java:566)
	at org.springframework.aop.support.AopUtils.invokeJoinpointUsingReflection(AopUtils.java:344)
	at org.springframework.aop.framework.Re', '2023-08-26 15:11:18.478000'),
        (36, 3, '등급 이름들 가져오기', 33, '2023-08-26 15:11:19.180000', '2023-08-26 15:11:19.406000', 'COMPLETED', 1, 4, 0, 4, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-26 15:11:19.423000'),
        (37, 6, '등급 재산정', 33, '2023-08-26 15:11:19.724000', '2023-08-26 15:11:20.446000', 'COMPLETED', 4, 38, 0, 38, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-26 15:11:20.462000'),
        (38, 3, '생일 쿠폰 정보 가져오기', 35, '2023-08-26 15:18:31.246000', '2023-08-26 15:18:31.510000', 'COMPLETED', 1, 0, 0, 0, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-26 15:18:31.527000'),
        (39, 2, '생일쿠폰 발급', 35, '2023-08-26 15:18:31.815000', '2023-08-26 15:18:32.053000', 'FAILED', 0, 10, 0, 0, 0, 0, 0, 2, 'FAILED', 'org.springframework.retry.RetryException: Non-skippable exception in recoverer while processing; nested exception is java.lang.NullPointerException
	at org.springframework.batch.core.step.item.FaultTolerantChunkProcessor$2.recover(FaultTolerantChunkProcessor.java:299)
	at org.springframework.retry.support.RetryTemplate.handleRetryExhausted(RetryTemplate.java:539)
	at org.springframework.retry.support.RetryTemplate.doExecute(RetryTemplate.java:387)
	at org.springframework.retry.support.RetryTemplate.execute(RetryTemplate.java:255)
	at org.springframework.batch.core.step.item.BatchRetryTemplate.execute(BatchRetryTemplate.java:217)
	at org.springframework.batch.core.step.item.FaultTolerantChunkProcessor.transform(FaultTolerantChunkProcessor.java:308)
	at org.springframework.batch.core.step.item.SimpleChunkProcessor.process(SimpleChunkProcessor.java:210)
	at org.springframework.batch.core.step.item.ChunkOrientedTasklet.execute(ChunkOrientedTasklet.java:77)
	at org.springframework.batch.core.step.tasklet.TaskletStep$ChunkTransactionCallback.doInTransaction(TaskletStep.java:407)
	at org.springframework.batch.core.step.tasklet.TaskletStep$ChunkTransactionCallback.doInTransaction(TaskletStep.java:331)
	at org.springframework.transaction.support.TransactionTemplate.execute(TransactionTemplate.java:140)
	at org.springframework.batch.core.step.tasklet.TaskletStep$2.doInChunkContext(TaskletStep.java:273)
	at org.springframework.batch.core.scope.context.StepContextRepeatCallback.doInIteration(StepContextRepeatCallback.java:82)
	at org.springframework.batch.repeat.support.RepeatTemplate.getNextResult(RepeatTemplate.java:375)
	at org.springframework.batch.repeat.support.RepeatTemplate.executeInternal(RepeatTemplate.java:215)
	at org.springframework.batch.repeat.support.RepeatTemplate.iterate(RepeatTemplate.java:145)
	at org.springframework.batch.core.step.tasklet.TaskletStep.doExecute(TaskletStep.java:258)
	at org.springframework.batch.core.step.AbstractStep.execute(AbstractStep.java:208)
	at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at java.base/jdk.internal.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.base/java.lang.reflect.Method.invoke(Method.java:566)
	at org.springframework.aop.support.AopUtils.invokeJoinpointUsingReflection(AopUtils.java:344)
	at org.springframework.aop.framework.Re', '2023-08-26 15:18:32.069000'),
        (40, 3, '등급 이름들 가져오기', 36, '2023-08-26 15:18:32.782000', '2023-08-26 15:18:33.007000', 'COMPLETED', 1, 4, 0, 4, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-26 15:18:33.023000'),
        (41, 6, '등급 재산정', 36, '2023-08-26 15:18:33.292000', '2023-08-26 15:18:33.965000', 'COMPLETED', 4, 38, 0, 38, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-26 15:18:33.981000'),
        (42, 4, '생일 쿠폰 정보 가져오기', 38, '2023-08-26 15:23:01.664000', '2023-08-26 15:23:02.018000', 'COMPLETED', 2, 1, 0, 1, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-26 15:23:02.034000'),
        (43, 4, '생일쿠폰 발급', 38, '2023-08-26 15:23:02.308000', '2023-08-26 15:23:02.662000', 'COMPLETED', 2, 11, 0, 11, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-26 15:23:02.679000'),
        (44, 3, '등급 이름들 가져오기', 39, '2023-08-26 15:23:03.348000', '2023-08-26 15:23:03.550000', 'COMPLETED', 1, 4, 0, 4, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-26 15:23:03.564000'),
        (45, 6, '등급 재산정', 39, '2023-08-26 15:23:03.817000', '2023-08-26 15:23:04.459000', 'COMPLETED', 4, 38, 0, 38, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-26 15:23:04.473000'),
        (46, 4, '생일 쿠폰 정보 가져오기', 41, '2023-08-26 23:56:07.339000', '2023-08-26 23:56:07.999000', 'COMPLETED', 2, 1, 0, 1, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-26 23:56:08.039000'),
        (47, 4, '생일쿠폰 발급', 41, '2023-08-26 23:56:08.639000', '2023-08-26 23:56:09.359000', 'COMPLETED', 2, 11, 0, 11, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-26 23:56:09.399000'),
        (48, 3, '등급 이름들 가져오기', 42, '2023-08-26 23:56:11.039000', '2023-08-26 23:56:11.499000', 'COMPLETED', 1, 4, 0, 4, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-26 23:56:11.539000'),
        (49, 6, '등급 재산정', 42, '2023-08-26 23:56:12.137000', '2023-08-26 23:56:13.759000', 'COMPLETED', 4, 38, 0, 38, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-26 23:56:13.799000'),
        (50, 4, '생일 쿠폰 정보 가져오기', 44, '2023-08-27 13:21:00.125000', '2023-08-27 13:21:00.443000', 'COMPLETED', 2, 1, 0, 1, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-27 13:21:00.458000'),
        (51, 4, '생일쿠폰 발급', 44, '2023-08-27 13:21:00.718000', '2023-08-27 13:21:01.043000', 'COMPLETED', 2, 11, 0, 11, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-27 13:21:01.061000'),
        (52, 3, '등급 이름들 가져오기', 45, '2023-08-27 13:21:01.739000', '2023-08-27 13:21:01.939000', 'COMPLETED', 1, 4, 0, 4, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-27 13:21:01.953000'),
        (53, 6, '등급 재산정', 45, '2023-08-27 13:21:02.198000', '2023-08-27 13:21:02.829000', 'COMPLETED', 4, 38, 0, 38, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-27 13:21:02.843000'),
        (54, 3, '휴면될 회원리스트 가져오기', 46, '2023-08-27 13:21:03.517000', '2023-08-27 13:21:03.707000', 'COMPLETED', 1, 0, 0, 0, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-27 13:21:03.721000'),
        (55, 3, 'statusChangeSuccessStep', 46, '2023-08-27 13:21:03.997000', '2023-08-27 13:21:04.178000', 'COMPLETED', 1, 0, 0, 0, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-27 13:21:04.193000'),
        (56, 3, '휴면될 회원리스트 가져오기', 47, '2023-08-27 14:36:00.729000', '2023-08-27 14:36:00.987000', 'COMPLETED', 1, 0, 0, 0, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-27 14:36:01.004000'),
        (57, 3, 'statusChangeSuccessStep', 47, '2023-08-27 14:36:01.335000', '2023-08-27 14:36:01.533000', 'COMPLETED', 1, 0, 0, 0, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-27 14:36:01.548000'),
        (58, 3, '휴면될 회원리스트 가져오기', 57, '2023-08-28 04:35:01.589000', '2023-08-28 04:35:02.099000', 'COMPLETED', 1, 0, 0, 0, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-28 04:35:02.139000'),
        (59, 3, 'statusChangeSuccessStep', 57, '2023-08-28 04:35:02.879000', '2023-08-28 04:35:03.339000', 'COMPLETED', 1, 0, 0, 0, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-28 04:35:03.379000'),
        (60, 3, '휴면될 회원리스트 가져오기', 58, '2023-08-28 05:49:01.539000', '2023-08-28 05:49:02.158000', 'ABANDONED', 0, 2, 0, 0, 0, 0, 0, 2, 'FAILED', 'org.springframework.retry.ExhaustedRetryException: Retry exhausted after last attempt in recovery path, but exception is not skippable.; nested exception is org.springframework.dao.DataIntegrityViolationException: store.cookshoong.www.cookshoongspringbatch.status.mapper.StatusMapper.updateAccounts (batch index #1) failed. Cause: java.sql.BatchUpdateException: Cannot add or update a child row: a foreign key constraint fails (`cookshoong_shop_dev`.`accounts`, CONSTRAINT `FK_status_TO_accounts_1` FOREIGN KEY (`status_code`) REFERENCES `account_status` (`status_code`))
; Cannot add or update a child row: a foreign key constraint fails (`cookshoong_shop_dev`.`accounts`, CONSTRAINT `FK_status_TO_accounts_1` FOREIGN KEY (`status_code`) REFERENCES `account_status` (`status_code`)); nested exception is java.sql.BatchUpdateException: Cannot add or update a child row: a foreign key constraint fails (`cookshoong_shop_dev`.`accounts`, CONSTRAINT `FK_status_TO_accounts_1` FOREIGN KEY (`status_code`) REFERENCES `account_status` (`status_code`))
	at org.springframework.batch.core.step.item.FaultTolerantChunkProcessor$5.recover(FaultTolerantChunkProcessor.java:429)
	at org.springframework.retry.support.RetryTemplate.handleRetryExhausted(RetryTemplate.java:539)
	at org.springframework.retry.support.RetryTemplate.doExecute(RetryTemplate.java:387)
	at org.springframework.retry.support.RetryTemplate.execute(RetryTemplate.java:255)
	at org.springframework.batch.core.step.item.BatchRetryTemplate.execute(BatchRetryTemplate.java:217)
	at org.springframework.batch.core.step.item.FaultTolerantChunkProcessor.write(FaultTolerantChunkProcessor.java:444)
	at org.springframework.batch.core.step.item.SimpleChunkProcessor.process(SimpleChunkProcessor.java:217)
	at org.springframework.batch.core.step.item.ChunkOrientedTasklet.execute(ChunkOrientedTasklet.java:77)
	at org.springframework.batch.core.step.tasklet.TaskletStep$ChunkTransactionCallback.doInTransaction(TaskletStep.java:407)
	at org.springframework.batch.core.step.tasklet.TaskletStep$ChunkTransactionCallback.doInTransaction(TaskletStep.java:331)
	at org.springframework.transaction.support.TransactionTemplate.execute(TransactionTemplate.java:140)
	at org.springframework.batch.core.step.tasklet.TaskletStep$2.doInChunkContext(TaskletStep.java:273)
	at org.springframework.batch.core.scope.context.StepContextRepeatCallback.doInIteration(StepContextRepeatCallback.java:82)
	at org.springframework.batch.repeat.support.RepeatTemplate.getNex', '2023-08-28 05:49:02.418000'),
        (61, 3, 'statusChangeFailStep', 58, '2023-08-28 05:49:03.038000', '2023-08-28 05:49:04.768000', 'COMPLETED', 1, 0, 0, 0, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-28 05:49:04.808000'),
        (62, 3, '휴면될 회원리스트 가져오기', 59, '2023-08-28 05:59:01.396000', '2023-08-28 05:59:02.005000', 'ABANDONED', 0, 2, 0, 0, 0, 0, 0, 2, 'FAILED', 'org.springframework.retry.ExhaustedRetryException: Retry exhausted after last attempt in recovery path, but exception is not skippable.; nested exception is org.springframework.dao.DataIntegrityViolationException: store.cookshoong.www.cookshoongspringbatch.status.mapper.StatusMapper.updateAccounts (batch index #1) failed. Cause: java.sql.BatchUpdateException: Cannot add or update a child row: a foreign key constraint fails (`cookshoong_shop_dev`.`accounts`, CONSTRAINT `FK_status_TO_accounts_1` FOREIGN KEY (`status_code`) REFERENCES `account_status` (`status_code`))
; Cannot add or update a child row: a foreign key constraint fails (`cookshoong_shop_dev`.`accounts`, CONSTRAINT `FK_status_TO_accounts_1` FOREIGN KEY (`status_code`) REFERENCES `account_status` (`status_code`)); nested exception is java.sql.BatchUpdateException: Cannot add or update a child row: a foreign key constraint fails (`cookshoong_shop_dev`.`accounts`, CONSTRAINT `FK_status_TO_accounts_1` FOREIGN KEY (`status_code`) REFERENCES `account_status` (`status_code`))
	at org.springframework.batch.core.step.item.FaultTolerantChunkProcessor$5.recover(FaultTolerantChunkProcessor.java:429)
	at org.springframework.retry.support.RetryTemplate.handleRetryExhausted(RetryTemplate.java:539)
	at org.springframework.retry.support.RetryTemplate.doExecute(RetryTemplate.java:387)
	at org.springframework.retry.support.RetryTemplate.execute(RetryTemplate.java:255)
	at org.springframework.batch.core.step.item.BatchRetryTemplate.execute(BatchRetryTemplate.java:217)
	at org.springframework.batch.core.step.item.FaultTolerantChunkProcessor.write(FaultTolerantChunkProcessor.java:444)
	at org.springframework.batch.core.step.item.SimpleChunkProcessor.process(SimpleChunkProcessor.java:217)
	at org.springframework.batch.core.step.item.ChunkOrientedTasklet.execute(ChunkOrientedTasklet.java:77)
	at org.springframework.batch.core.step.tasklet.TaskletStep$ChunkTransactionCallback.doInTransaction(TaskletStep.java:407)
	at org.springframework.batch.core.step.tasklet.TaskletStep$ChunkTransactionCallback.doInTransaction(TaskletStep.java:331)
	at org.springframework.transaction.support.TransactionTemplate.execute(TransactionTemplate.java:140)
	at org.springframework.batch.core.step.tasklet.TaskletStep$2.doInChunkContext(TaskletStep.java:273)
	at org.springframework.batch.core.scope.context.StepContextRepeatCallback.doInIteration(StepContextRepeatCallback.java:82)
	at org.springframework.batch.repeat.support.RepeatTemplate.getNex', '2023-08-28 05:59:02.245000'),
        (63, 3, 'statusChangeFailStep', 59, '2023-08-28 05:59:02.826000', '2023-08-28 05:59:04.305000', 'COMPLETED', 1, 0, 0, 0, 0, 0, 0, 0, 'FAILED', '', '2023-08-28 05:59:04.345000'),
        (64, 3, '휴면될 회원리스트 가져오기', 60, '2023-08-28 06:04:01.159000', '2023-08-28 06:04:01.719000', 'ABANDONED', 0, 2, 0, 0, 0, 0, 0, 2, 'FAILED', 'org.springframework.retry.ExhaustedRetryException: Retry exhausted after last attempt in recovery path, but exception is not skippable.; nested exception is org.springframework.dao.DataIntegrityViolationException: store.cookshoong.www.cookshoongspringbatch.status.mapper.StatusMapper.updateAccounts (batch index #1) failed. Cause: java.sql.BatchUpdateException: Cannot add or update a child row: a foreign key constraint fails (`cookshoong_shop_dev`.`accounts`, CONSTRAINT `FK_status_TO_accounts_1` FOREIGN KEY (`status_code`) REFERENCES `account_status` (`status_code`))
; Cannot add or update a child row: a foreign key constraint fails (`cookshoong_shop_dev`.`accounts`, CONSTRAINT `FK_status_TO_accounts_1` FOREIGN KEY (`status_code`) REFERENCES `account_status` (`status_code`)); nested exception is java.sql.BatchUpdateException: Cannot add or update a child row: a foreign key constraint fails (`cookshoong_shop_dev`.`accounts`, CONSTRAINT `FK_status_TO_accounts_1` FOREIGN KEY (`status_code`) REFERENCES `account_status` (`status_code`))
	at org.springframework.batch.core.step.item.FaultTolerantChunkProcessor$5.recover(FaultTolerantChunkProcessor.java:429)
	at org.springframework.retry.support.RetryTemplate.handleRetryExhausted(RetryTemplate.java:539)
	at org.springframework.retry.support.RetryTemplate.doExecute(RetryTemplate.java:387)
	at org.springframework.retry.support.RetryTemplate.execute(RetryTemplate.java:255)
	at org.springframework.batch.core.step.item.BatchRetryTemplate.execute(BatchRetryTemplate.java:217)
	at org.springframework.batch.core.step.item.FaultTolerantChunkProcessor.write(FaultTolerantChunkProcessor.java:444)
	at org.springframework.batch.core.step.item.SimpleChunkProcessor.process(SimpleChunkProcessor.java:217)
	at org.springframework.batch.core.step.item.ChunkOrientedTasklet.execute(ChunkOrientedTasklet.java:77)
	at org.springframework.batch.core.step.tasklet.TaskletStep$ChunkTransactionCallback.doInTransaction(TaskletStep.java:407)
	at org.springframework.batch.core.step.tasklet.TaskletStep$ChunkTransactionCallback.doInTransaction(TaskletStep.java:331)
	at org.springframework.transaction.support.TransactionTemplate.execute(TransactionTemplate.java:140)
	at org.springframework.batch.core.step.tasklet.TaskletStep$2.doInChunkContext(TaskletStep.java:273)
	at org.springframework.batch.core.scope.context.StepContextRepeatCallback.doInIteration(StepContextRepeatCallback.java:82)
	at org.springframework.batch.repeat.support.RepeatTemplate.getNex', '2023-08-28 06:04:01.898000'),
        (65, 3, 'statusChangeFailStep', 60, '2023-08-28 06:04:02.289000', '2023-08-28 06:04:03.829000', 'FAILED', 1, 0, 0, 0, 0, 0, 0, 0, 'FAILED', '', '2023-08-28 06:04:03.849000'),
        (66, 3, '휴면될 회원리스트 가져오기', 61, '2023-08-28 09:38:01.071000', '2023-08-28 09:38:01.481000', 'ABANDONED', 0, 2, 0, 0, 0, 0, 0, 2, 'FAILED', 'org.springframework.retry.ExhaustedRetryException: Retry exhausted after last attempt in recovery path, but exception is not skippable.; nested exception is org.springframework.dao.DataIntegrityViolationException: store.cookshoong.www.cookshoongspringbatch.status.mapper.StatusMapper.updateAccounts (batch index #1) failed. Cause: java.sql.BatchUpdateException: Cannot add or update a child row: a foreign key constraint fails (`cookshoong_shop_dev`.`accounts`, CONSTRAINT `FK_status_TO_accounts_1` FOREIGN KEY (`status_code`) REFERENCES `account_status` (`status_code`))
; Cannot add or update a child row: a foreign key constraint fails (`cookshoong_shop_dev`.`accounts`, CONSTRAINT `FK_status_TO_accounts_1` FOREIGN KEY (`status_code`) REFERENCES `account_status` (`status_code`)); nested exception is java.sql.BatchUpdateException: Cannot add or update a child row: a foreign key constraint fails (`cookshoong_shop_dev`.`accounts`, CONSTRAINT `FK_status_TO_accounts_1` FOREIGN KEY (`status_code`) REFERENCES `account_status` (`status_code`))
	at org.springframework.batch.core.step.item.FaultTolerantChunkProcessor$5.recover(FaultTolerantChunkProcessor.java:429)
	at org.springframework.retry.support.RetryTemplate.handleRetryExhausted(RetryTemplate.java:539)
	at org.springframework.retry.support.RetryTemplate.doExecute(RetryTemplate.java:387)
	at org.springframework.retry.support.RetryTemplate.execute(RetryTemplate.java:255)
	at org.springframework.batch.core.step.item.BatchRetryTemplate.execute(BatchRetryTemplate.java:217)
	at org.springframework.batch.core.step.item.FaultTolerantChunkProcessor.write(FaultTolerantChunkProcessor.java:444)
	at org.springframework.batch.core.step.item.SimpleChunkProcessor.process(SimpleChunkProcessor.java:217)
	at org.springframework.batch.core.step.item.ChunkOrientedTasklet.execute(ChunkOrientedTasklet.java:77)
	at org.springframework.batch.core.step.tasklet.TaskletStep$ChunkTransactionCallback.doInTransaction(TaskletStep.java:407)
	at org.springframework.batch.core.step.tasklet.TaskletStep$ChunkTransactionCallback.doInTransaction(TaskletStep.java:331)
	at org.springframework.transaction.support.TransactionTemplate.execute(TransactionTemplate.java:140)
	at org.springframework.batch.core.step.tasklet.TaskletStep$2.doInChunkContext(TaskletStep.java:273)
	at org.springframework.batch.core.scope.context.StepContextRepeatCallback.doInIteration(StepContextRepeatCallback.java:82)
	at org.springframework.batch.repeat.support.RepeatTemplate.getNex', '2023-08-28 09:38:01.641000'),
        (67, 3, 'statusChangeFailStep', 61, '2023-08-28 09:38:02.023000', '2023-08-28 09:38:03.518000', 'FAILED', 1, 0, 0, 0, 0, 0, 0, 0, 'FAILED', '', '2023-08-28 09:38:03.539000'),
        (68, 3, '휴면될 회원리스트 가져오기', 62, '2023-08-28 11:43:01.035000', '2023-08-28 11:43:01.439000', 'COMPLETED', 1, 2, 0, 2, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-28 11:43:01.462000'),
        (69, 3, 'statusChangeSuccessStep', 62, '2023-08-28 11:43:01.928000', '2023-08-28 11:43:02.221000', 'COMPLETED', 1, 0, 0, 0, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-28 11:43:02.243000'),
        (70, 3, '휴면될 회원리스트 가져오기', 63, '2023-08-28 11:44:00.986000', '2023-08-28 11:44:01.306000', 'COMPLETED', 1, 0, 0, 0, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-28 11:44:01.331000'),
        (71, 3, 'statusChangeSuccessStep', 63, '2023-08-28 11:44:01.748000', '2023-08-28 11:44:02.015000', 'COMPLETED', 1, 0, 0, 0, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-28 11:44:02.034000'),
        (72, 3, '휴면될 회원리스트 가져오기', 64, '2023-08-28 12:20:01.030000', '2023-08-28 12:20:01.380000', 'COMPLETED', 1, 0, 0, 0, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-28 12:20:01.404000'),
        (73, 3, 'statusChangeSuccessStep', 64, '2023-08-28 12:20:01.850000', '2023-08-28 12:20:02.131000', 'COMPLETED', 1, 0, 0, 0, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-28 12:20:02.157000'),
        (74, 3, '휴면될 회원리스트 가져오기', 65, '2023-08-28 12:24:01.008000', '2023-08-28 12:24:01.421000', 'ABANDONED', 0, 1, 0, 0, 0, 0, 0, 2, 'FAILED', 'org.springframework.retry.ExhaustedRetryException: Retry exhausted after last attempt in recovery path, but exception is not skippable.; nested exception is org.springframework.dao.DataIntegrityViolationException: store.cookshoong.www.cookshoongspringbatch.status.mapper.StatusMapper.updateAccounts (batch index #1) failed. Cause: java.sql.BatchUpdateException: Cannot add or update a child row: a foreign key constraint fails (`cookshoong_shop_dev`.`accounts`, CONSTRAINT `FK_status_TO_accounts_1` FOREIGN KEY (`status_code`) REFERENCES `account_status` (`status_code`))
; Cannot add or update a child row: a foreign key constraint fails (`cookshoong_shop_dev`.`accounts`, CONSTRAINT `FK_status_TO_accounts_1` FOREIGN KEY (`status_code`) REFERENCES `account_status` (`status_code`)); nested exception is java.sql.BatchUpdateException: Cannot add or update a child row: a foreign key constraint fails (`cookshoong_shop_dev`.`accounts`, CONSTRAINT `FK_status_TO_accounts_1` FOREIGN KEY (`status_code`) REFERENCES `account_status` (`status_code`))
	at org.springframework.batch.core.step.item.FaultTolerantChunkProcessor$5.recover(FaultTolerantChunkProcessor.java:429)
	at org.springframework.retry.support.RetryTemplate.handleRetryExhausted(RetryTemplate.java:539)
	at org.springframework.retry.support.RetryTemplate.doExecute(RetryTemplate.java:387)
	at org.springframework.retry.support.RetryTemplate.execute(RetryTemplate.java:255)
	at org.springframework.batch.core.step.item.BatchRetryTemplate.execute(BatchRetryTemplate.java:217)
	at org.springframework.batch.core.step.item.FaultTolerantChunkProcessor.write(FaultTolerantChunkProcessor.java:444)
	at org.springframework.batch.core.step.item.SimpleChunkProcessor.process(SimpleChunkProcessor.java:217)
	at org.springframework.batch.core.step.item.ChunkOrientedTasklet.execute(ChunkOrientedTasklet.java:77)
	at org.springframework.batch.core.step.tasklet.TaskletStep$ChunkTransactionCallback.doInTransaction(TaskletStep.java:407)
	at org.springframework.batch.core.step.tasklet.TaskletStep$ChunkTransactionCallback.doInTransaction(TaskletStep.java:331)
	at org.springframework.transaction.support.TransactionTemplate.execute(TransactionTemplate.java:140)
	at org.springframework.batch.core.step.tasklet.TaskletStep$2.doInChunkContext(TaskletStep.java:273)
	at org.springframework.batch.core.scope.context.StepContextRepeatCallback.doInIteration(StepContextRepeatCallback.java:82)
	at org.springframework.batch.repeat.support.RepeatTemplate.getNex', '2023-08-28 12:24:01.580000'),
        (75, 3, 'statusChangeFailStep', 65, '2023-08-28 12:24:01.953000', '2023-08-28 12:24:03.446000', 'FAILED', 1, 0, 0, 0, 0, 0, 0, 0, 'FAILED', '', '2023-08-28 12:24:03.476000'),
        (76, 4, '생일 쿠폰 정보 가져오기', 66, '2023-08-29 09:57:41.718000', '2023-08-29 09:57:42.157000', 'COMPLETED', 2, 1, 0, 1, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-29 09:57:42.182000'),
        (77, 4, '생일쿠폰 발급', 66, '2023-08-29 09:57:42.615000', '2023-08-29 09:57:43.083000', 'COMPLETED', 2, 11, 0, 11, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-29 09:57:43.110000'),
        (78, 3, '등급 이름들 가져오기', 67, '2023-08-29 09:57:44.202000', '2023-08-29 09:57:44.531000', 'COMPLETED', 1, 4, 0, 4, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-29 09:57:44.560000'),
        (79, 2, '등급 재산정', 67, '2023-08-29 09:57:44.989000', '2023-08-29 09:57:45.323000', 'FAILED', 0, 10, 0, 0, 0, 0, 0, 1, 'FAILED', 'org.mybatis.spring.MyBatisSystemException: nested exception is org.apache.ibatis.exceptions.PersistenceException: 
### Error updating database.  Cause: java.lang.IllegalArgumentException: Mapped Statements collection does not contain value for store.cookshoong.www.cookshoongspringbatch.rank.mapper.RankMapper.insertRankCoupon
### Cause: java.lang.IllegalArgumentException: Mapped Statements collection does not contain value for store.cookshoong.www.cookshoongspringbatch.rank.mapper.RankMapper.insertRankCoupon
	at org.mybatis.spring.MyBatisExceptionTranslator.translateExceptionIfPossible(MyBatisExceptionTranslator.java:97)
	at org.mybatis.spring.SqlSessionTemplate$SqlSessionInterceptor.invoke(SqlSessionTemplate.java:439)
	at com.sun.proxy.$Proxy113.update(Unknown Source)
	at org.mybatis.spring.SqlSessionTemplate.update(SqlSessionTemplate.java:288)
	at org.mybatis.spring.batch.MyBatisBatchItemWriter.write(MyBatisBatchItemWriter.java:145)
	at org.mybatis.spring.batch.MyBatisBatchItemWriter$$FastClassBySpringCGLIB$$50a27cfd.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.invokeJoinpoint(CglibAopProxy.java:793)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:163)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:763)
	at org.springframework.aop.support.DelegatingIntroductionInterceptor.doProceed(DelegatingIntroductionInterceptor.java:137)
	at org.springframework.aop.support.DelegatingIntroductionInterceptor.invoke(DelegatingIntroductionInterceptor.java:124)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:186)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:763)
	at org.springframework.aop.framework.CglibAopProxy$DynamicAdvisedInterceptor.intercept(CglibAopProxy.java:708)
	at org.mybatis.spring.batch.MyBatisBatchItemWriter$$EnhancerBySpringCGLIB$$f7f80c89.write(<generated>)
	at org.springframework.batch.item.support.CompositeItemWriter.write(CompositeItemWriter.java:59)
	at org.springframework.batch.item.support.CompositeItemWriter$$FastClassBySpringCGLIB$$fd4a76ae.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocat', '2023-08-29 09:57:45.350000'),
        (80, 3, '휴면될 회원리스트 가져오기', 68, '2023-08-29 09:57:46.526000', '2023-08-29 09:57:46.861000', 'COMPLETED', 1, 0, 0, 0, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-29 09:57:46.884000'),
        (81, 3, 'statusChangeSuccessStep', 68, '2023-08-29 09:57:47.353000', '2023-08-29 09:57:47.644000', 'COMPLETED', 1, 0, 0, 0, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-29 09:57:47.669000'),
        (82, 3, '휴면될 회원리스트 가져오기', 69, '2023-08-29 09:58:00.876000', '2023-08-29 09:58:01.212000', 'COMPLETED', 1, 1, 0, 1, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-29 09:58:01.237000'),
        (83, 3, 'statusChangeSuccessStep', 69, '2023-08-29 09:58:01.681000', '2023-08-29 09:58:01.985000', 'COMPLETED', 1, 0, 0, 0, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-29 09:58:02.007000'),
        (84, 4, '생일 쿠폰 정보 가져오기', 70, '2023-08-29 13:55:40.632000', '2023-08-29 13:55:41.081000', 'COMPLETED', 2, 1, 0, 1, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-29 13:55:41.106000'),
        (85, 4, '생일쿠폰 발급', 70, '2023-08-29 13:55:41.536000', '2023-08-29 13:55:42.148000', 'COMPLETED', 2, 11, 0, 11, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-29 13:55:42.173000'),
        (86, 3, '등급 이름들 가져오기', 71, '2023-08-29 13:55:43.280000', '2023-08-29 13:55:43.616000', 'COMPLETED', 1, 4, 0, 4, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-29 13:55:43.639000'),
        (87, 2, '등급 재산정', 71, '2023-08-29 13:55:44.036000', '2023-08-29 13:55:44.403000', 'FAILED', 0, 10, 0, 0, 0, 0, 0, 1, 'FAILED', 'org.mybatis.spring.MyBatisSystemException: nested exception is org.apache.ibatis.reflection.ReflectionException: There is no getter for property named ''list'' in ''class store.cookshoong.www.cookshoongspringbatch.rank.dto.UpdateAccountRankDto''
	at org.mybatis.spring.MyBatisExceptionTranslator.translateExceptionIfPossible(MyBatisExceptionTranslator.java:97)
	at org.mybatis.spring.SqlSessionTemplate$SqlSessionInterceptor.invoke(SqlSessionTemplate.java:439)
	at com.sun.proxy.$Proxy113.update(Unknown Source)
	at org.mybatis.spring.SqlSessionTemplate.update(SqlSessionTemplate.java:288)
	at org.mybatis.spring.batch.MyBatisBatchItemWriter.write(MyBatisBatchItemWriter.java:145)
	at org.mybatis.spring.batch.MyBatisBatchItemWriter$$FastClassBySpringCGLIB$$50a27cfd.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.invokeJoinpoint(CglibAopProxy.java:793)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:163)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:763)
	at org.springframework.aop.support.DelegatingIntroductionInterceptor.doProceed(DelegatingIntroductionInterceptor.java:137)
	at org.springframework.aop.support.DelegatingIntroductionInterceptor.invoke(DelegatingIntroductionInterceptor.java:124)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:186)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:763)
	at org.springframework.aop.framework.CglibAopProxy$DynamicAdvisedInterceptor.intercept(CglibAopProxy.java:708)
	at org.mybatis.spring.batch.MyBatisBatchItemWriter$$EnhancerBySpringCGLIB$$d3ab43c5.write(<generated>)
	at org.springframework.batch.item.support.CompositeItemWriter.write(CompositeItemWriter.java:59)
	at org.springframework.batch.item.support.CompositeItemWriter$$FastClassBySpringCGLIB$$fd4a76ae.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.invokeJoinpoint(CglibAopProxy.java:793)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:163)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:763)
	at org.spr', '2023-08-29 13:55:44.426000'),
        (88, 3, '휴면될 회원리스트 가져오기', 73, '2023-08-29 13:56:00.892000', '2023-08-29 13:56:01.196000', 'COMPLETED', 1, 0, 0, 0, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-29 13:56:01.216000'),
        (89, 3, 'statusChangeSuccessStep', 73, '2023-08-29 13:56:01.647000', '2023-08-29 13:56:01.941000', 'COMPLETED', 1, 0, 0, 0, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-29 13:56:01.969000'),
        (90, 4, '생일 쿠폰 정보 가져오기', 74, '2023-08-29 13:59:13.085000', '2023-08-29 13:59:13.607000', 'COMPLETED', 2, 1, 0, 1, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-29 13:59:13.632000'),
        (91, 4, '생일쿠폰 발급', 74, '2023-08-29 13:59:14.161000', '2023-08-29 13:59:14.725000', 'COMPLETED', 2, 11, 0, 11, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-29 13:59:14.748000'),
        (92, 3, '등급 이름들 가져오기', 75, '2023-08-29 13:59:15.869000', '2023-08-29 13:59:16.210000', 'COMPLETED', 1, 4, 0, 4, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-29 13:59:16.249000'),
        (93, 2, '등급 재산정', 75, '2023-08-29 13:59:16.687000', '2023-08-29 13:59:17.232000', 'FAILED', 0, 10, 0, 0, 0, 0, 0, 1, 'FAILED', 'org.mybatis.spring.MyBatisSystemException: nested exception is org.apache.ibatis.reflection.ReflectionException: There is no getter for property named ''list'' in ''class store.cookshoong.www.cookshoongspringbatch.rank.dto.UpdateAccountRankDto''
	at org.mybatis.spring.MyBatisExceptionTranslator.translateExceptionIfPossible(MyBatisExceptionTranslator.java:97)
	at org.mybatis.spring.SqlSessionTemplate$SqlSessionInterceptor.invoke(SqlSessionTemplate.java:439)
	at com.sun.proxy.$Proxy113.update(Unknown Source)
	at org.mybatis.spring.SqlSessionTemplate.update(SqlSessionTemplate.java:288)
	at org.mybatis.spring.batch.MyBatisBatchItemWriter.write(MyBatisBatchItemWriter.java:145)
	at org.mybatis.spring.batch.MyBatisBatchItemWriter$$FastClassBySpringCGLIB$$50a27cfd.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.invokeJoinpoint(CglibAopProxy.java:793)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:163)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:763)
	at org.springframework.aop.support.DelegatingIntroductionInterceptor.doProceed(DelegatingIntroductionInterceptor.java:137)
	at org.springframework.aop.support.DelegatingIntroductionInterceptor.invoke(DelegatingIntroductionInterceptor.java:124)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:186)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:763)
	at org.springframework.aop.framework.CglibAopProxy$DynamicAdvisedInterceptor.intercept(CglibAopProxy.java:708)
	at org.mybatis.spring.batch.MyBatisBatchItemWriter$$EnhancerBySpringCGLIB$$a09d4dc5.write(<generated>)
	at org.springframework.batch.item.support.CompositeItemWriter.write(CompositeItemWriter.java:59)
	at org.springframework.batch.item.support.CompositeItemWriter$$FastClassBySpringCGLIB$$fd4a76ae.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.invokeJoinpoint(CglibAopProxy.java:793)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:163)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:763)
	at org.spr', '2023-08-29 13:59:17.273000'),
        (94, 4, '생일 쿠폰 정보 가져오기', 77, '2023-08-29 14:06:04.734000', '2023-08-29 14:06:05.235000', 'COMPLETED', 2, 1, 0, 1, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-29 14:06:05.259000'),
        (95, 4, '생일쿠폰 발급', 77, '2023-08-29 14:06:05.749000', '2023-08-29 14:06:06.280000', 'COMPLETED', 2, 11, 0, 11, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-29 14:06:06.317000'),
        (96, 3, '등급 이름들 가져오기', 78, '2023-08-29 14:06:07.423000', '2023-08-29 14:06:07.746000', 'COMPLETED', 1, 4, 0, 4, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-29 14:06:07.774000'),
        (97, 2, '등급 재산정', 78, '2023-08-29 14:06:08.165000', '2023-08-29 14:06:08.539000', 'FAILED', 0, 10, 0, 0, 0, 0, 0, 1, 'FAILED', 'org.mybatis.spring.MyBatisSystemException: nested exception is org.apache.ibatis.reflection.ReflectionException: There is no getter for property named ''list'' in ''class store.cookshoong.www.cookshoongspringbatch.rank.dto.UpdateAccountRankDto''
	at org.mybatis.spring.MyBatisExceptionTranslator.translateExceptionIfPossible(MyBatisExceptionTranslator.java:97)
	at org.mybatis.spring.SqlSessionTemplate$SqlSessionInterceptor.invoke(SqlSessionTemplate.java:439)
	at com.sun.proxy.$Proxy113.update(Unknown Source)
	at org.mybatis.spring.SqlSessionTemplate.update(SqlSessionTemplate.java:288)
	at org.mybatis.spring.batch.MyBatisBatchItemWriter.write(MyBatisBatchItemWriter.java:145)
	at org.mybatis.spring.batch.MyBatisBatchItemWriter$$FastClassBySpringCGLIB$$50a27cfd.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.invokeJoinpoint(CglibAopProxy.java:793)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:163)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:763)
	at org.springframework.aop.support.DelegatingIntroductionInterceptor.doProceed(DelegatingIntroductionInterceptor.java:137)
	at org.springframework.aop.support.DelegatingIntroductionInterceptor.invoke(DelegatingIntroductionInterceptor.java:124)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:186)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:763)
	at org.springframework.aop.framework.CglibAopProxy$DynamicAdvisedInterceptor.intercept(CglibAopProxy.java:708)
	at org.mybatis.spring.batch.MyBatisBatchItemWriter$$EnhancerBySpringCGLIB$$ab788e9.write(<generated>)
	at org.springframework.batch.item.support.CompositeItemWriter.write(CompositeItemWriter.java:59)
	at org.springframework.batch.item.support.CompositeItemWriter$$FastClassBySpringCGLIB$$fd4a76ae.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.invokeJoinpoint(CglibAopProxy.java:793)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:163)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:763)
	at org.spri', '2023-08-29 14:06:08.561000'),
        (98, 4, '생일 쿠폰 정보 가져오기', 80, '2023-08-29 14:13:55.667000', '2023-08-29 14:13:56.112000', 'COMPLETED', 2, 1, 0, 1, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-29 14:13:56.147000'),
        (99, 4, '생일쿠폰 발급', 80, '2023-08-29 14:13:56.614000', '2023-08-29 14:13:57.126000', 'COMPLETED', 2, 11, 0, 11, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-29 14:13:57.150000'),
        (100, 3, '등급 이름들 가져오기', 81, '2023-08-29 14:13:58.271000', '2023-08-29 14:13:58.614000', 'COMPLETED', 1, 4, 0, 4, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-29 14:13:58.636000'),
        (101, 2, '등급 재산정', 81, '2023-08-29 14:13:59.030000', '2023-08-29 14:13:59.397000', 'FAILED', 0, 10, 0, 0, 0, 0, 0, 1, 'FAILED', 'org.mybatis.spring.MyBatisSystemException: nested exception is org.apache.ibatis.reflection.ReflectionException: There is no getter for property named ''list'' in ''class store.cookshoong.www.cookshoongspringbatch.rank.dto.UpdateAccountRankDto''
	at org.mybatis.spring.MyBatisExceptionTranslator.translateExceptionIfPossible(MyBatisExceptionTranslator.java:97)
	at org.mybatis.spring.SqlSessionTemplate$SqlSessionInterceptor.invoke(SqlSessionTemplate.java:439)
	at com.sun.proxy.$Proxy113.update(Unknown Source)
	at org.mybatis.spring.SqlSessionTemplate.update(SqlSessionTemplate.java:288)
	at org.mybatis.spring.batch.MyBatisBatchItemWriter.write(MyBatisBatchItemWriter.java:145)
	at org.mybatis.spring.batch.MyBatisBatchItemWriter$$FastClassBySpringCGLIB$$50a27cfd.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.invokeJoinpoint(CglibAopProxy.java:793)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:163)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:763)
	at org.springframework.aop.support.DelegatingIntroductionInterceptor.doProceed(DelegatingIntroductionInterceptor.java:137)
	at org.springframework.aop.support.DelegatingIntroductionInterceptor.invoke(DelegatingIntroductionInterceptor.java:124)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:186)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:763)
	at org.springframework.aop.framework.CglibAopProxy$DynamicAdvisedInterceptor.intercept(CglibAopProxy.java:708)
	at org.mybatis.spring.batch.MyBatisBatchItemWriter$$EnhancerBySpringCGLIB$$e585d528.write(<generated>)
	at org.springframework.batch.item.support.CompositeItemWriter.write(CompositeItemWriter.java:59)
	at org.springframework.batch.item.support.CompositeItemWriter$$FastClassBySpringCGLIB$$fd4a76ae.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.invokeJoinpoint(CglibAopProxy.java:793)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:163)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:763)
	at org.spr', '2023-08-29 14:13:59.424000'),
        (102, 4, '생일 쿠폰 정보 가져오기', 83, '2023-08-29 14:52:16.141000', '2023-08-29 14:52:16.641000', 'COMPLETED', 2, 1, 0, 1, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-29 14:52:16.666000'),
        (103, 4, '생일쿠폰 발급', 83, '2023-08-29 14:52:17.086000', '2023-08-29 14:52:17.545000', 'COMPLETED', 2, 11, 0, 11, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-29 14:52:17.568000'),
        (104, 3, '등급 이름들 가져오기', 84, '2023-08-29 14:52:18.663000', '2023-08-29 14:52:19.014000', 'COMPLETED', 1, 4, 0, 4, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-29 14:52:19.037000'),
        (105, 2, '등급 재산정', 84, '2023-08-29 14:52:19.444000', '2023-08-29 14:52:19.822000', 'FAILED', 0, 10, 0, 0, 0, 0, 0, 2, 'FAILED', 'org.springframework.retry.ExhaustedRetryException: Retry exhausted after last attempt in recovery path, but exception is not skippable.; nested exception is org.mybatis.spring.MyBatisSystemException: nested exception is org.apache.ibatis.reflection.ReflectionException: There is no getter for property named ''list'' in ''class store.cookshoong.www.cookshoongspringbatch.rank.dto.UpdateAccountRankDto''
	at org.springframework.batch.core.step.item.FaultTolerantChunkProcessor$5.recover(FaultTolerantChunkProcessor.java:429)
	at org.springframework.retry.support.RetryTemplate.handleRetryExhausted(RetryTemplate.java:539)
	at org.springframework.retry.support.RetryTemplate.doExecute(RetryTemplate.java:387)
	at org.springframework.retry.support.RetryTemplate.execute(RetryTemplate.java:255)
	at org.springframework.batch.core.step.item.BatchRetryTemplate.execute(BatchRetryTemplate.java:217)
	at org.springframework.batch.core.step.item.FaultTolerantChunkProcessor.write(FaultTolerantChunkProcessor.java:444)
	at org.springframework.batch.core.step.item.SimpleChunkProcessor.process(SimpleChunkProcessor.java:217)
	at org.springframework.batch.core.step.item.ChunkOrientedTasklet.execute(ChunkOrientedTasklet.java:77)
	at org.springframework.batch.core.step.tasklet.TaskletStep$ChunkTransactionCallback.doInTransaction(TaskletStep.java:407)
	at org.springframework.batch.core.step.tasklet.TaskletStep$ChunkTransactionCallback.doInTransaction(TaskletStep.java:331)
	at org.springframework.transaction.support.TransactionTemplate.execute(TransactionTemplate.java:140)
	at org.springframework.batch.core.step.tasklet.TaskletStep$2.doInChunkContext(TaskletStep.java:273)
	at org.springframework.batch.core.scope.context.StepContextRepeatCallback.doInIteration(StepContextRepeatCallback.java:82)
	at org.springframework.batch.repeat.support.RepeatTemplate.getNextResult(RepeatTemplate.java:375)
	at org.springframework.batch.repeat.support.RepeatTemplate.executeInternal(RepeatTemplate.java:215)
	at org.springframework.batch.repeat.support.RepeatTemplate.iterate(RepeatTemplate.java:145)
	at org.springframework.batch.core.step.tasklet.TaskletStep.doExecute(TaskletStep.java:258)
	at org.springframework.batch.core.step.AbstractStep.execute(AbstractStep.java:208)
	at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at java.base/jdk.internal.reflect.DelegatingMethodAccessorI', '2023-08-29 14:52:19.842000'),
        (106, 4, '생일 쿠폰 정보 가져오기', 86, '2023-08-29 15:04:12.356000', '2023-08-29 15:04:12.800000', 'COMPLETED', 2, 1, 0, 1, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-29 15:04:12.824000'),
        (107, 4, '생일쿠폰 발급', 86, '2023-08-29 15:04:13.254000', '2023-08-29 15:04:13.799000', 'COMPLETED', 2, 11, 0, 11, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-29 15:04:13.822000'),
        (108, 3, '등급 이름들 가져오기', 87, '2023-08-29 15:04:15.651000', '2023-08-29 15:04:15.968000', 'COMPLETED', 1, 4, 0, 4, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-29 15:04:15.991000'),
        (109, 6, '등급 재산정', 87, '2023-08-29 15:04:16.449000', '2023-08-29 15:04:17.470000', 'COMPLETED', 4, 38, 0, 38, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-29 15:04:17.495000'),
        (110, 4, '생일 쿠폰 정보 가져오기', 89, '2023-08-29 19:16:38.153000', '2023-08-29 19:16:38.533000', 'COMPLETED', 2, 1, 0, 1, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-29 19:16:38.553000'),
        (111, 4, '생일쿠폰 발급', 89, '2023-08-29 19:16:38.936000', '2023-08-29 19:16:39.377000', 'COMPLETED', 2, 11, 0, 11, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-29 19:16:39.397000'),
        (112, 3, '등급 이름들 가져오기', 90, '2023-08-29 19:16:40.362000', '2023-08-29 19:16:40.661000', 'COMPLETED', 1, 4, 0, 4, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-29 19:16:40.684000'),
        (113, 2, '등급 재산정', 90, '2023-08-29 19:16:41.044000', '2023-08-29 19:16:41.413000', 'FAILED', 0, 10, 0, 0, 0, 0, 0, 2, 'FAILED', 'org.springframework.retry.ExhaustedRetryException: Retry exhausted after last attempt in recovery path, but exception is not skippable.; nested exception is org.mybatis.spring.MyBatisSystemException: nested exception is org.apache.ibatis.reflection.ReflectionException: There is no getter for property named ''list'' in ''class store.cookshoong.www.cookshoongspringbatch.rank.dto.UpdateAccountRankDto''
	at org.springframework.batch.core.step.item.FaultTolerantChunkProcessor$5.recover(FaultTolerantChunkProcessor.java:429)
	at org.springframework.retry.support.RetryTemplate.handleRetryExhausted(RetryTemplate.java:539)
	at org.springframework.retry.support.RetryTemplate.doExecute(RetryTemplate.java:387)
	at org.springframework.retry.support.RetryTemplate.execute(RetryTemplate.java:255)
	at org.springframework.batch.core.step.item.BatchRetryTemplate.execute(BatchRetryTemplate.java:217)
	at org.springframework.batch.core.step.item.FaultTolerantChunkProcessor.write(FaultTolerantChunkProcessor.java:444)
	at org.springframework.batch.core.step.item.SimpleChunkProcessor.process(SimpleChunkProcessor.java:217)
	at org.springframework.batch.core.step.item.ChunkOrientedTasklet.execute(ChunkOrientedTasklet.java:77)
	at org.springframework.batch.core.step.tasklet.TaskletStep$ChunkTransactionCallback.doInTransaction(TaskletStep.java:407)
	at org.springframework.batch.core.step.tasklet.TaskletStep$ChunkTransactionCallback.doInTransaction(TaskletStep.java:331)
	at org.springframework.transaction.support.TransactionTemplate.execute(TransactionTemplate.java:140)
	at org.springframework.batch.core.step.tasklet.TaskletStep$2.doInChunkContext(TaskletStep.java:273)
	at org.springframework.batch.core.scope.context.StepContextRepeatCallback.doInIteration(StepContextRepeatCallback.java:82)
	at org.springframework.batch.repeat.support.RepeatTemplate.getNextResult(RepeatTemplate.java:375)
	at org.springframework.batch.repeat.support.RepeatTemplate.executeInternal(RepeatTemplate.java:215)
	at org.springframework.batch.repeat.support.RepeatTemplate.iterate(RepeatTemplate.java:145)
	at org.springframework.batch.core.step.tasklet.TaskletStep.doExecute(TaskletStep.java:258)
	at org.springframework.batch.core.step.AbstractStep.execute(AbstractStep.java:208)
	at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at java.base/jdk.internal.reflect.DelegatingMethodAccessorI', '2023-08-29 19:16:41.436000'),
        (114, 3, '등급 이름들 가져오기', 92, '2023-08-29 19:17:00.750000', '2023-08-29 19:17:01.043000', 'COMPLETED', 1, 4, 0, 4, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-29 19:17:01.062000'),
        (115, 2, '등급 재산정', 92, '2023-08-29 19:17:01.453000', '2023-08-29 19:17:01.805000', 'FAILED', 0, 10, 0, 0, 0, 0, 0, 2, 'FAILED', 'org.springframework.retry.ExhaustedRetryException: Retry exhausted after last attempt in recovery path, but exception is not skippable.; nested exception is org.mybatis.spring.MyBatisSystemException: nested exception is org.apache.ibatis.reflection.ReflectionException: There is no getter for property named ''list'' in ''class store.cookshoong.www.cookshoongspringbatch.rank.dto.UpdateAccountRankDto''
	at org.springframework.batch.core.step.item.FaultTolerantChunkProcessor$5.recover(FaultTolerantChunkProcessor.java:429)
	at org.springframework.retry.support.RetryTemplate.handleRetryExhausted(RetryTemplate.java:539)
	at org.springframework.retry.support.RetryTemplate.doExecute(RetryTemplate.java:387)
	at org.springframework.retry.support.RetryTemplate.execute(RetryTemplate.java:255)
	at org.springframework.batch.core.step.item.BatchRetryTemplate.execute(BatchRetryTemplate.java:217)
	at org.springframework.batch.core.step.item.FaultTolerantChunkProcessor.write(FaultTolerantChunkProcessor.java:444)
	at org.springframework.batch.core.step.item.SimpleChunkProcessor.process(SimpleChunkProcessor.java:217)
	at org.springframework.batch.core.step.item.ChunkOrientedTasklet.execute(ChunkOrientedTasklet.java:77)
	at org.springframework.batch.core.step.tasklet.TaskletStep$ChunkTransactionCallback.doInTransaction(TaskletStep.java:407)
	at org.springframework.batch.core.step.tasklet.TaskletStep$ChunkTransactionCallback.doInTransaction(TaskletStep.java:331)
	at org.springframework.transaction.support.TransactionTemplate.execute(TransactionTemplate.java:140)
	at org.springframework.batch.core.step.tasklet.TaskletStep$2.doInChunkContext(TaskletStep.java:273)
	at org.springframework.batch.core.scope.context.StepContextRepeatCallback.doInIteration(StepContextRepeatCallback.java:82)
	at org.springframework.batch.repeat.support.RepeatTemplate.getNextResult(RepeatTemplate.java:375)
	at org.springframework.batch.repeat.support.RepeatTemplate.executeInternal(RepeatTemplate.java:215)
	at org.springframework.batch.repeat.support.RepeatTemplate.iterate(RepeatTemplate.java:145)
	at org.springframework.batch.core.step.tasklet.TaskletStep.doExecute(TaskletStep.java:258)
	at org.springframework.batch.core.step.AbstractStep.execute(AbstractStep.java:208)
	at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at java.base/jdk.internal.reflect.DelegatingMethodAccessorI', '2023-08-29 19:17:01.826000'),
        (116, 4, '생일 쿠폰 정보 가져오기', 93, '2023-08-29 10:17:33.367000', '2023-08-29 10:17:33.781000', 'COMPLETED', 2, 1, 0, 1, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-29 10:17:33.807000'),
        (117, 4, '생일쿠폰 발급', 93, '2023-08-29 10:17:34.181000', '2023-08-29 10:17:34.603000', 'COMPLETED', 2, 11, 0, 11, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-29 10:17:34.625000'),
        (118, 3, '등급 이름들 가져오기', 94, '2023-08-29 10:17:35.562000', '2023-08-29 10:17:35.840000', 'COMPLETED', 1, 4, 0, 4, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-29 10:17:35.866000'),
        (119, 2, '등급 재산정', 94, '2023-08-29 10:17:36.224000', '2023-08-29 10:17:36.564000', 'FAILED', 0, 10, 0, 0, 0, 0, 0, 2, 'FAILED', 'org.springframework.retry.ExhaustedRetryException: Retry exhausted after last attempt in recovery path, but exception is not skippable.; nested exception is org.mybatis.spring.MyBatisSystemException: nested exception is org.apache.ibatis.reflection.ReflectionException: There is no getter for property named ''list'' in ''class store.cookshoong.www.cookshoongspringbatch.rank.dto.UpdateAccountRankDto''
	at org.springframework.batch.core.step.item.FaultTolerantChunkProcessor$5.recover(FaultTolerantChunkProcessor.java:429)
	at org.springframework.retry.support.RetryTemplate.handleRetryExhausted(RetryTemplate.java:539)
	at org.springframework.retry.support.RetryTemplate.doExecute(RetryTemplate.java:387)
	at org.springframework.retry.support.RetryTemplate.execute(RetryTemplate.java:255)
	at org.springframework.batch.core.step.item.BatchRetryTemplate.execute(BatchRetryTemplate.java:217)
	at org.springframework.batch.core.step.item.FaultTolerantChunkProcessor.write(FaultTolerantChunkProcessor.java:444)
	at org.springframework.batch.core.step.item.SimpleChunkProcessor.process(SimpleChunkProcessor.java:217)
	at org.springframework.batch.core.step.item.ChunkOrientedTasklet.execute(ChunkOrientedTasklet.java:77)
	at org.springframework.batch.core.step.tasklet.TaskletStep$ChunkTransactionCallback.doInTransaction(TaskletStep.java:407)
	at org.springframework.batch.core.step.tasklet.TaskletStep$ChunkTransactionCallback.doInTransaction(TaskletStep.java:331)
	at org.springframework.transaction.support.TransactionTemplate.execute(TransactionTemplate.java:140)
	at org.springframework.batch.core.step.tasklet.TaskletStep$2.doInChunkContext(TaskletStep.java:273)
	at org.springframework.batch.core.scope.context.StepContextRepeatCallback.doInIteration(StepContextRepeatCallback.java:82)
	at org.springframework.batch.repeat.support.RepeatTemplate.getNextResult(RepeatTemplate.java:375)
	at org.springframework.batch.repeat.support.RepeatTemplate.executeInternal(RepeatTemplate.java:215)
	at org.springframework.batch.repeat.support.RepeatTemplate.iterate(RepeatTemplate.java:145)
	at org.springframework.batch.core.step.tasklet.TaskletStep.doExecute(TaskletStep.java:258)
	at org.springframework.batch.core.step.AbstractStep.execute(AbstractStep.java:208)
	at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at java.base/jdk.internal.reflect.DelegatingMethodAccessorI', '2023-08-29 10:17:36.583000'),
        (120, 3, '등급 이름들 가져오기', 96, '2023-08-29 10:18:00.743000', '2023-08-29 10:18:01.026000', 'COMPLETED', 1, 4, 0, 4, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-29 10:18:01.045000'),
        (121, 2, '등급 재산정', 96, '2023-08-29 10:18:01.455000', '2023-08-29 10:18:01.788000', 'FAILED', 0, 10, 0, 0, 0, 0, 0, 2, 'FAILED', 'org.springframework.retry.ExhaustedRetryException: Retry exhausted after last attempt in recovery path, but exception is not skippable.; nested exception is org.mybatis.spring.MyBatisSystemException: nested exception is org.apache.ibatis.reflection.ReflectionException: There is no getter for property named ''list'' in ''class store.cookshoong.www.cookshoongspringbatch.rank.dto.UpdateAccountRankDto''
	at org.springframework.batch.core.step.item.FaultTolerantChunkProcessor$5.recover(FaultTolerantChunkProcessor.java:429)
	at org.springframework.retry.support.RetryTemplate.handleRetryExhausted(RetryTemplate.java:539)
	at org.springframework.retry.support.RetryTemplate.doExecute(RetryTemplate.java:387)
	at org.springframework.retry.support.RetryTemplate.execute(RetryTemplate.java:255)
	at org.springframework.batch.core.step.item.BatchRetryTemplate.execute(BatchRetryTemplate.java:217)
	at org.springframework.batch.core.step.item.FaultTolerantChunkProcessor.write(FaultTolerantChunkProcessor.java:444)
	at org.springframework.batch.core.step.item.SimpleChunkProcessor.process(SimpleChunkProcessor.java:217)
	at org.springframework.batch.core.step.item.ChunkOrientedTasklet.execute(ChunkOrientedTasklet.java:77)
	at org.springframework.batch.core.step.tasklet.TaskletStep$ChunkTransactionCallback.doInTransaction(TaskletStep.java:407)
	at org.springframework.batch.core.step.tasklet.TaskletStep$ChunkTransactionCallback.doInTransaction(TaskletStep.java:331)
	at org.springframework.transaction.support.TransactionTemplate.execute(TransactionTemplate.java:140)
	at org.springframework.batch.core.step.tasklet.TaskletStep$2.doInChunkContext(TaskletStep.java:273)
	at org.springframework.batch.core.scope.context.StepContextRepeatCallback.doInIteration(StepContextRepeatCallback.java:82)
	at org.springframework.batch.repeat.support.RepeatTemplate.getNextResult(RepeatTemplate.java:375)
	at org.springframework.batch.repeat.support.RepeatTemplate.executeInternal(RepeatTemplate.java:215)
	at org.springframework.batch.repeat.support.RepeatTemplate.iterate(RepeatTemplate.java:145)
	at org.springframework.batch.core.step.tasklet.TaskletStep.doExecute(TaskletStep.java:258)
	at org.springframework.batch.core.step.AbstractStep.execute(AbstractStep.java:208)
	at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at java.base/jdk.internal.reflect.DelegatingMethodAccessorI', '2023-08-29 10:18:01.807000'),
        (122, 4, '생일 쿠폰 정보 가져오기', 97, '2023-08-29 11:06:49.428000', '2023-08-29 11:06:49.826000', 'COMPLETED', 2, 1, 0, 1, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-29 11:06:49.846000'),
        (123, 4, '생일쿠폰 발급', 97, '2023-08-29 11:06:50.227000', '2023-08-29 11:06:50.708000', 'COMPLETED', 2, 11, 0, 11, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-29 11:06:50.729000'),
        (124, 3, '등급 이름들 가져오기', 98, '2023-08-29 11:06:51.698000', '2023-08-29 11:06:52.007000', 'COMPLETED', 1, 4, 0, 4, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-29 11:06:52.030000'),
        (125, 2, '등급 재산정', 98, '2023-08-29 11:06:52.417000', '2023-08-29 11:06:52.796000', 'FAILED', 0, 10, 0, 0, 0, 0, 0, 2, 'FAILED', 'org.springframework.retry.ExhaustedRetryException: Retry exhausted after last attempt in recovery path, but exception is not skippable.; nested exception is org.mybatis.spring.MyBatisSystemException: nested exception is org.apache.ibatis.reflection.ReflectionException: There is no getter for property named ''list'' in ''class store.cookshoong.www.cookshoongspringbatch.rank.dto.UpdateAccountRankDto''
	at org.springframework.batch.core.step.item.FaultTolerantChunkProcessor$5.recover(FaultTolerantChunkProcessor.java:429)
	at org.springframework.retry.support.RetryTemplate.handleRetryExhausted(RetryTemplate.java:539)
	at org.springframework.retry.support.RetryTemplate.doExecute(RetryTemplate.java:387)
	at org.springframework.retry.support.RetryTemplate.execute(RetryTemplate.java:255)
	at org.springframework.batch.core.step.item.BatchRetryTemplate.execute(BatchRetryTemplate.java:217)
	at org.springframework.batch.core.step.item.FaultTolerantChunkProcessor.write(FaultTolerantChunkProcessor.java:444)
	at org.springframework.batch.core.step.item.SimpleChunkProcessor.process(SimpleChunkProcessor.java:217)
	at org.springframework.batch.core.step.item.ChunkOrientedTasklet.execute(ChunkOrientedTasklet.java:77)
	at org.springframework.batch.core.step.tasklet.TaskletStep$ChunkTransactionCallback.doInTransaction(TaskletStep.java:407)
	at org.springframework.batch.core.step.tasklet.TaskletStep$ChunkTransactionCallback.doInTransaction(TaskletStep.java:331)
	at org.springframework.transaction.support.TransactionTemplate.execute(TransactionTemplate.java:140)
	at org.springframework.batch.core.step.tasklet.TaskletStep$2.doInChunkContext(TaskletStep.java:273)
	at org.springframework.batch.core.scope.context.StepContextRepeatCallback.doInIteration(StepContextRepeatCallback.java:82)
	at org.springframework.batch.repeat.support.RepeatTemplate.getNextResult(RepeatTemplate.java:375)
	at org.springframework.batch.repeat.support.RepeatTemplate.executeInternal(RepeatTemplate.java:215)
	at org.springframework.batch.repeat.support.RepeatTemplate.iterate(RepeatTemplate.java:145)
	at org.springframework.batch.core.step.tasklet.TaskletStep.doExecute(TaskletStep.java:258)
	at org.springframework.batch.core.step.AbstractStep.execute(AbstractStep.java:208)
	at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at java.base/jdk.internal.reflect.DelegatingMethodAccessorI', '2023-08-29 11:06:52.816000'),
        (126, 3, '등급 이름들 가져오기', 100, '2023-08-29 11:07:00.789000', '2023-08-29 11:07:01.083000', 'COMPLETED', 1, 4, 0, 4, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-29 11:07:01.106000'),
        (127, 2, '등급 재산정', 100, '2023-08-29 11:07:01.550000', '2023-08-29 11:07:01.899000', 'FAILED', 0, 10, 0, 0, 0, 0, 0, 2, 'FAILED', 'org.springframework.retry.ExhaustedRetryException: Retry exhausted after last attempt in recovery path, but exception is not skippable.; nested exception is org.mybatis.spring.MyBatisSystemException: nested exception is org.apache.ibatis.reflection.ReflectionException: There is no getter for property named ''list'' in ''class store.cookshoong.www.cookshoongspringbatch.rank.dto.UpdateAccountRankDto''
	at org.springframework.batch.core.step.item.FaultTolerantChunkProcessor$5.recover(FaultTolerantChunkProcessor.java:429)
	at org.springframework.retry.support.RetryTemplate.handleRetryExhausted(RetryTemplate.java:539)
	at org.springframework.retry.support.RetryTemplate.doExecute(RetryTemplate.java:387)
	at org.springframework.retry.support.RetryTemplate.execute(RetryTemplate.java:255)
	at org.springframework.batch.core.step.item.BatchRetryTemplate.execute(BatchRetryTemplate.java:217)
	at org.springframework.batch.core.step.item.FaultTolerantChunkProcessor.write(FaultTolerantChunkProcessor.java:444)
	at org.springframework.batch.core.step.item.SimpleChunkProcessor.process(SimpleChunkProcessor.java:217)
	at org.springframework.batch.core.step.item.ChunkOrientedTasklet.execute(ChunkOrientedTasklet.java:77)
	at org.springframework.batch.core.step.tasklet.TaskletStep$ChunkTransactionCallback.doInTransaction(TaskletStep.java:407)
	at org.springframework.batch.core.step.tasklet.TaskletStep$ChunkTransactionCallback.doInTransaction(TaskletStep.java:331)
	at org.springframework.transaction.support.TransactionTemplate.execute(TransactionTemplate.java:140)
	at org.springframework.batch.core.step.tasklet.TaskletStep$2.doInChunkContext(TaskletStep.java:273)
	at org.springframework.batch.core.scope.context.StepContextRepeatCallback.doInIteration(StepContextRepeatCallback.java:82)
	at org.springframework.batch.repeat.support.RepeatTemplate.getNextResult(RepeatTemplate.java:375)
	at org.springframework.batch.repeat.support.RepeatTemplate.executeInternal(RepeatTemplate.java:215)
	at org.springframework.batch.repeat.support.RepeatTemplate.iterate(RepeatTemplate.java:145)
	at org.springframework.batch.core.step.tasklet.TaskletStep.doExecute(TaskletStep.java:258)
	at org.springframework.batch.core.step.AbstractStep.execute(AbstractStep.java:208)
	at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at java.base/jdk.internal.reflect.DelegatingMethodAccessorI', '2023-08-29 11:07:01.922000'),
        (128, 4, '생일 쿠폰 정보 가져오기', 101, '2023-08-29 11:19:45.436000', '2023-08-29 11:19:45.791000', 'COMPLETED', 2, 1, 0, 1, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-29 11:19:45.811000'),
        (129, 4, '생일쿠폰 발급', 101, '2023-08-29 11:19:46.175000', '2023-08-29 11:19:46.603000', 'COMPLETED', 2, 11, 0, 11, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-29 11:19:46.626000'),
        (130, 3, '등급 이름들 가져오기', 102, '2023-08-29 11:19:47.549000', '2023-08-29 11:19:47.836000', 'COMPLETED', 1, 4, 0, 4, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-29 11:19:47.858000'),
        (131, 2, '등급 재산정', 102, '2023-08-29 11:19:48.203000', '2023-08-29 11:19:48.538000', 'FAILED', 0, 10, 0, 0, 0, 0, 0, 2, 'FAILED', 'org.springframework.retry.ExhaustedRetryException: Retry exhausted after last attempt in recovery path, but exception is not skippable.; nested exception is org.mybatis.spring.MyBatisSystemException: nested exception is org.apache.ibatis.reflection.ReflectionException: There is no getter for property named ''list'' in ''class store.cookshoong.www.cookshoongspringbatch.rank.dto.UpdateAccountRankDto''
	at org.springframework.batch.core.step.item.FaultTolerantChunkProcessor$5.recover(FaultTolerantChunkProcessor.java:429)
	at org.springframework.retry.support.RetryTemplate.handleRetryExhausted(RetryTemplate.java:539)
	at org.springframework.retry.support.RetryTemplate.doExecute(RetryTemplate.java:387)
	at org.springframework.retry.support.RetryTemplate.execute(RetryTemplate.java:255)
	at org.springframework.batch.core.step.item.BatchRetryTemplate.execute(BatchRetryTemplate.java:217)
	at org.springframework.batch.core.step.item.FaultTolerantChunkProcessor.write(FaultTolerantChunkProcessor.java:444)
	at org.springframework.batch.core.step.item.SimpleChunkProcessor.process(SimpleChunkProcessor.java:217)
	at org.springframework.batch.core.step.item.ChunkOrientedTasklet.execute(ChunkOrientedTasklet.java:77)
	at org.springframework.batch.core.step.tasklet.TaskletStep$ChunkTransactionCallback.doInTransaction(TaskletStep.java:407)
	at org.springframework.batch.core.step.tasklet.TaskletStep$ChunkTransactionCallback.doInTransaction(TaskletStep.java:331)
	at org.springframework.transaction.support.TransactionTemplate.execute(TransactionTemplate.java:140)
	at org.springframework.batch.core.step.tasklet.TaskletStep$2.doInChunkContext(TaskletStep.java:273)
	at org.springframework.batch.core.scope.context.StepContextRepeatCallback.doInIteration(StepContextRepeatCallback.java:82)
	at org.springframework.batch.repeat.support.RepeatTemplate.getNextResult(RepeatTemplate.java:375)
	at org.springframework.batch.repeat.support.RepeatTemplate.executeInternal(RepeatTemplate.java:215)
	at org.springframework.batch.repeat.support.RepeatTemplate.iterate(RepeatTemplate.java:145)
	at org.springframework.batch.core.step.tasklet.TaskletStep.doExecute(TaskletStep.java:258)
	at org.springframework.batch.core.step.AbstractStep.execute(AbstractStep.java:208)
	at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at java.base/jdk.internal.reflect.DelegatingMethodAccessorI', '2023-08-29 11:19:48.563000'),
        (132, 3, '등급 이름들 가져오기', 104, '2023-08-29 11:20:00.722000', '2023-08-29 11:20:00.999000', 'COMPLETED', 1, 4, 0, 4, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-29 11:20:01.023000'),
        (133, 2, '등급 재산정', 104, '2023-08-29 11:20:01.400000', '2023-08-29 11:20:01.714000', 'FAILED', 0, 10, 0, 0, 0, 0, 0, 2, 'FAILED', 'org.springframework.retry.ExhaustedRetryException: Retry exhausted after last attempt in recovery path, but exception is not skippable.; nested exception is org.mybatis.spring.MyBatisSystemException: nested exception is org.apache.ibatis.reflection.ReflectionException: There is no getter for property named ''list'' in ''class store.cookshoong.www.cookshoongspringbatch.rank.dto.UpdateAccountRankDto''
	at org.springframework.batch.core.step.item.FaultTolerantChunkProcessor$5.recover(FaultTolerantChunkProcessor.java:429)
	at org.springframework.retry.support.RetryTemplate.handleRetryExhausted(RetryTemplate.java:539)
	at org.springframework.retry.support.RetryTemplate.doExecute(RetryTemplate.java:387)
	at org.springframework.retry.support.RetryTemplate.execute(RetryTemplate.java:255)
	at org.springframework.batch.core.step.item.BatchRetryTemplate.execute(BatchRetryTemplate.java:217)
	at org.springframework.batch.core.step.item.FaultTolerantChunkProcessor.write(FaultTolerantChunkProcessor.java:444)
	at org.springframework.batch.core.step.item.SimpleChunkProcessor.process(SimpleChunkProcessor.java:217)
	at org.springframework.batch.core.step.item.ChunkOrientedTasklet.execute(ChunkOrientedTasklet.java:77)
	at org.springframework.batch.core.step.tasklet.TaskletStep$ChunkTransactionCallback.doInTransaction(TaskletStep.java:407)
	at org.springframework.batch.core.step.tasklet.TaskletStep$ChunkTransactionCallback.doInTransaction(TaskletStep.java:331)
	at org.springframework.transaction.support.TransactionTemplate.execute(TransactionTemplate.java:140)
	at org.springframework.batch.core.step.tasklet.TaskletStep$2.doInChunkContext(TaskletStep.java:273)
	at org.springframework.batch.core.scope.context.StepContextRepeatCallback.doInIteration(StepContextRepeatCallback.java:82)
	at org.springframework.batch.repeat.support.RepeatTemplate.getNextResult(RepeatTemplate.java:375)
	at org.springframework.batch.repeat.support.RepeatTemplate.executeInternal(RepeatTemplate.java:215)
	at org.springframework.batch.repeat.support.RepeatTemplate.iterate(RepeatTemplate.java:145)
	at org.springframework.batch.core.step.tasklet.TaskletStep.doExecute(TaskletStep.java:258)
	at org.springframework.batch.core.step.AbstractStep.execute(AbstractStep.java:208)
	at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at java.base/jdk.internal.reflect.DelegatingMethodAccessorI', '2023-08-29 11:20:01.735000'),
        (134, 3, '등급 이름들 가져오기', 105, '2023-08-29 11:21:00.793000', '2023-08-29 11:21:01.074000', 'COMPLETED', 1, 4, 0, 4, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-29 11:21:01.097000'),
        (135, 2, '등급 재산정', 105, '2023-08-29 11:21:01.485000', '2023-08-29 11:21:01.820000', 'FAILED', 0, 10, 0, 0, 0, 0, 0, 2, 'FAILED', 'org.springframework.retry.ExhaustedRetryException: Retry exhausted after last attempt in recovery path, but exception is not skippable.; nested exception is org.mybatis.spring.MyBatisSystemException: nested exception is org.apache.ibatis.reflection.ReflectionException: There is no getter for property named ''list'' in ''class store.cookshoong.www.cookshoongspringbatch.rank.dto.UpdateAccountRankDto''
	at org.springframework.batch.core.step.item.FaultTolerantChunkProcessor$5.recover(FaultTolerantChunkProcessor.java:429)
	at org.springframework.retry.support.RetryTemplate.handleRetryExhausted(RetryTemplate.java:539)
	at org.springframework.retry.support.RetryTemplate.doExecute(RetryTemplate.java:387)
	at org.springframework.retry.support.RetryTemplate.execute(RetryTemplate.java:255)
	at org.springframework.batch.core.step.item.BatchRetryTemplate.execute(BatchRetryTemplate.java:217)
	at org.springframework.batch.core.step.item.FaultTolerantChunkProcessor.write(FaultTolerantChunkProcessor.java:444)
	at org.springframework.batch.core.step.item.SimpleChunkProcessor.process(SimpleChunkProcessor.java:217)
	at org.springframework.batch.core.step.item.ChunkOrientedTasklet.execute(ChunkOrientedTasklet.java:77)
	at org.springframework.batch.core.step.tasklet.TaskletStep$ChunkTransactionCallback.doInTransaction(TaskletStep.java:407)
	at org.springframework.batch.core.step.tasklet.TaskletStep$ChunkTransactionCallback.doInTransaction(TaskletStep.java:331)
	at org.springframework.transaction.support.TransactionTemplate.execute(TransactionTemplate.java:140)
	at org.springframework.batch.core.step.tasklet.TaskletStep$2.doInChunkContext(TaskletStep.java:273)
	at org.springframework.batch.core.scope.context.StepContextRepeatCallback.doInIteration(StepContextRepeatCallback.java:82)
	at org.springframework.batch.repeat.support.RepeatTemplate.getNextResult(RepeatTemplate.java:375)
	at org.springframework.batch.repeat.support.RepeatTemplate.executeInternal(RepeatTemplate.java:215)
	at org.springframework.batch.repeat.support.RepeatTemplate.iterate(RepeatTemplate.java:145)
	at org.springframework.batch.core.step.tasklet.TaskletStep.doExecute(TaskletStep.java:258)
	at org.springframework.batch.core.step.AbstractStep.execute(AbstractStep.java:208)
	at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at java.base/jdk.internal.reflect.DelegatingMethodAccessorI', '2023-08-29 11:21:01.839000'),
        (136, 4, '생일 쿠폰 정보 가져오기', 106, '2023-08-29 11:21:38.637000', '2023-08-29 11:21:39.031000', 'COMPLETED', 2, 1, 0, 1, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-29 11:21:39.052000'),
        (137, 4, '생일쿠폰 발급', 106, '2023-08-29 11:21:39.421000', '2023-08-29 11:21:39.880000', 'COMPLETED', 2, 11, 0, 11, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-29 11:21:39.903000'),
        (138, 3, '등급 이름들 가져오기', 107, '2023-08-29 11:21:40.906000', '2023-08-29 11:21:41.196000', 'COMPLETED', 1, 4, 0, 4, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-29 11:21:41.218000'),
        (139, 2, '등급 재산정', 107, '2023-08-29 11:21:41.619000', '2023-08-29 11:21:41.972000', 'FAILED', 0, 10, 0, 0, 0, 0, 0, 2, 'FAILED', 'org.springframework.retry.ExhaustedRetryException: Retry exhausted after last attempt in recovery path, but exception is not skippable.; nested exception is org.mybatis.spring.MyBatisSystemException: nested exception is org.apache.ibatis.reflection.ReflectionException: There is no getter for property named ''list'' in ''class store.cookshoong.www.cookshoongspringbatch.rank.dto.UpdateAccountRankDto''
	at org.springframework.batch.core.step.item.FaultTolerantChunkProcessor$5.recover(FaultTolerantChunkProcessor.java:429)
	at org.springframework.retry.support.RetryTemplate.handleRetryExhausted(RetryTemplate.java:539)
	at org.springframework.retry.support.RetryTemplate.doExecute(RetryTemplate.java:387)
	at org.springframework.retry.support.RetryTemplate.execute(RetryTemplate.java:255)
	at org.springframework.batch.core.step.item.BatchRetryTemplate.execute(BatchRetryTemplate.java:217)
	at org.springframework.batch.core.step.item.FaultTolerantChunkProcessor.write(FaultTolerantChunkProcessor.java:444)
	at org.springframework.batch.core.step.item.SimpleChunkProcessor.process(SimpleChunkProcessor.java:217)
	at org.springframework.batch.core.step.item.ChunkOrientedTasklet.execute(ChunkOrientedTasklet.java:77)
	at org.springframework.batch.core.step.tasklet.TaskletStep$ChunkTransactionCallback.doInTransaction(TaskletStep.java:407)
	at org.springframework.batch.core.step.tasklet.TaskletStep$ChunkTransactionCallback.doInTransaction(TaskletStep.java:331)
	at org.springframework.transaction.support.TransactionTemplate.execute(TransactionTemplate.java:140)
	at org.springframework.batch.core.step.tasklet.TaskletStep$2.doInChunkContext(TaskletStep.java:273)
	at org.springframework.batch.core.scope.context.StepContextRepeatCallback.doInIteration(StepContextRepeatCallback.java:82)
	at org.springframework.batch.repeat.support.RepeatTemplate.getNextResult(RepeatTemplate.java:375)
	at org.springframework.batch.repeat.support.RepeatTemplate.executeInternal(RepeatTemplate.java:215)
	at org.springframework.batch.repeat.support.RepeatTemplate.iterate(RepeatTemplate.java:145)
	at org.springframework.batch.core.step.tasklet.TaskletStep.doExecute(TaskletStep.java:258)
	at org.springframework.batch.core.step.AbstractStep.execute(AbstractStep.java:208)
	at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at java.base/jdk.internal.reflect.DelegatingMethodAccessorI', '2023-08-29 11:21:41.995000'),
        (140, 3, '등급 이름들 가져오기', 109, '2023-08-29 11:22:00.742000', '2023-08-29 11:22:01.015000', 'COMPLETED', 1, 4, 0, 4, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-29 11:22:01.038000'),
        (141, 2, '등급 재산정', 109, '2023-08-29 11:22:01.437000', '2023-08-29 11:22:01.765000', 'FAILED', 0, 10, 0, 0, 0, 0, 0, 2, 'FAILED', 'org.springframework.retry.ExhaustedRetryException: Retry exhausted after last attempt in recovery path, but exception is not skippable.; nested exception is org.mybatis.spring.MyBatisSystemException: nested exception is org.apache.ibatis.reflection.ReflectionException: There is no getter for property named ''list'' in ''class store.cookshoong.www.cookshoongspringbatch.rank.dto.UpdateAccountRankDto''
	at org.springframework.batch.core.step.item.FaultTolerantChunkProcessor$5.recover(FaultTolerantChunkProcessor.java:429)
	at org.springframework.retry.support.RetryTemplate.handleRetryExhausted(RetryTemplate.java:539)
	at org.springframework.retry.support.RetryTemplate.doExecute(RetryTemplate.java:387)
	at org.springframework.retry.support.RetryTemplate.execute(RetryTemplate.java:255)
	at org.springframework.batch.core.step.item.BatchRetryTemplate.execute(BatchRetryTemplate.java:217)
	at org.springframework.batch.core.step.item.FaultTolerantChunkProcessor.write(FaultTolerantChunkProcessor.java:444)
	at org.springframework.batch.core.step.item.SimpleChunkProcessor.process(SimpleChunkProcessor.java:217)
	at org.springframework.batch.core.step.item.ChunkOrientedTasklet.execute(ChunkOrientedTasklet.java:77)
	at org.springframework.batch.core.step.tasklet.TaskletStep$ChunkTransactionCallback.doInTransaction(TaskletStep.java:407)
	at org.springframework.batch.core.step.tasklet.TaskletStep$ChunkTransactionCallback.doInTransaction(TaskletStep.java:331)
	at org.springframework.transaction.support.TransactionTemplate.execute(TransactionTemplate.java:140)
	at org.springframework.batch.core.step.tasklet.TaskletStep$2.doInChunkContext(TaskletStep.java:273)
	at org.springframework.batch.core.scope.context.StepContextRepeatCallback.doInIteration(StepContextRepeatCallback.java:82)
	at org.springframework.batch.repeat.support.RepeatTemplate.getNextResult(RepeatTemplate.java:375)
	at org.springframework.batch.repeat.support.RepeatTemplate.executeInternal(RepeatTemplate.java:215)
	at org.springframework.batch.repeat.support.RepeatTemplate.iterate(RepeatTemplate.java:145)
	at org.springframework.batch.core.step.tasklet.TaskletStep.doExecute(TaskletStep.java:258)
	at org.springframework.batch.core.step.AbstractStep.execute(AbstractStep.java:208)
	at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at java.base/jdk.internal.reflect.DelegatingMethodAccessorI', '2023-08-29 11:22:01.786000'),
        (142, 3, '등급 이름들 가져오기', 110, '2023-08-29 11:23:00.802000', '2023-08-29 11:23:01.104000', 'COMPLETED', 1, 4, 0, 4, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-29 11:23:01.126000'),
        (143, 2, '등급 재산정', 110, '2023-08-29 11:23:01.515000', '2023-08-29 11:23:01.832000', 'FAILED', 0, 10, 0, 0, 0, 0, 0, 2, 'FAILED', 'org.springframework.retry.ExhaustedRetryException: Retry exhausted after last attempt in recovery path, but exception is not skippable.; nested exception is org.mybatis.spring.MyBatisSystemException: nested exception is org.apache.ibatis.reflection.ReflectionException: There is no getter for property named ''list'' in ''class store.cookshoong.www.cookshoongspringbatch.rank.dto.UpdateAccountRankDto''
	at org.springframework.batch.core.step.item.FaultTolerantChunkProcessor$5.recover(FaultTolerantChunkProcessor.java:429)
	at org.springframework.retry.support.RetryTemplate.handleRetryExhausted(RetryTemplate.java:539)
	at org.springframework.retry.support.RetryTemplate.doExecute(RetryTemplate.java:387)
	at org.springframework.retry.support.RetryTemplate.execute(RetryTemplate.java:255)
	at org.springframework.batch.core.step.item.BatchRetryTemplate.execute(BatchRetryTemplate.java:217)
	at org.springframework.batch.core.step.item.FaultTolerantChunkProcessor.write(FaultTolerantChunkProcessor.java:444)
	at org.springframework.batch.core.step.item.SimpleChunkProcessor.process(SimpleChunkProcessor.java:217)
	at org.springframework.batch.core.step.item.ChunkOrientedTasklet.execute(ChunkOrientedTasklet.java:77)
	at org.springframework.batch.core.step.tasklet.TaskletStep$ChunkTransactionCallback.doInTransaction(TaskletStep.java:407)
	at org.springframework.batch.core.step.tasklet.TaskletStep$ChunkTransactionCallback.doInTransaction(TaskletStep.java:331)
	at org.springframework.transaction.support.TransactionTemplate.execute(TransactionTemplate.java:140)
	at org.springframework.batch.core.step.tasklet.TaskletStep$2.doInChunkContext(TaskletStep.java:273)
	at org.springframework.batch.core.scope.context.StepContextRepeatCallback.doInIteration(StepContextRepeatCallback.java:82)
	at org.springframework.batch.repeat.support.RepeatTemplate.getNextResult(RepeatTemplate.java:375)
	at org.springframework.batch.repeat.support.RepeatTemplate.executeInternal(RepeatTemplate.java:215)
	at org.springframework.batch.repeat.support.RepeatTemplate.iterate(RepeatTemplate.java:145)
	at org.springframework.batch.core.step.tasklet.TaskletStep.doExecute(TaskletStep.java:258)
	at org.springframework.batch.core.step.AbstractStep.execute(AbstractStep.java:208)
	at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at java.base/jdk.internal.reflect.DelegatingMethodAccessorI', '2023-08-29 11:23:01.854000'),
        (144, 4, '생일 쿠폰 정보 가져오기', 111, '2023-08-29 11:23:17.345000', '2023-08-29 11:23:17.783000', 'COMPLETED', 2, 1, 0, 1, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-29 11:23:17.806000'),
        (145, 4, '생일쿠폰 발급', 111, '2023-08-29 11:23:18.188000', '2023-08-29 11:23:18.635000', 'COMPLETED', 2, 11, 0, 11, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-29 11:23:18.658000'),
        (146, 3, '등급 이름들 가져오기', 112, '2023-08-29 11:23:19.626000', '2023-08-29 11:23:19.924000', 'COMPLETED', 1, 4, 0, 4, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-29 11:23:19.947000'),
        (147, 2, '등급 재산정', 112, '2023-08-29 11:23:20.327000', '2023-08-29 11:24:26.416000', 'FAILED', 0, 10, 0, 0, 0, 0, 0, 2, 'FAILED', 'org.springframework.retry.ExhaustedRetryException: Retry exhausted after last attempt in recovery path, but exception is not skippable.; nested exception is org.mybatis.spring.MyBatisSystemException: nested exception is org.apache.ibatis.reflection.ReflectionException: There is no getter for property named ''list'' in ''class store.cookshoong.www.cookshoongspringbatch.rank.dto.UpdateAccountRankDto''
	at org.springframework.batch.core.step.item.FaultTolerantChunkProcessor$5.recover(FaultTolerantChunkProcessor.java:429)
	at org.springframework.retry.support.RetryTemplate.handleRetryExhausted(RetryTemplate.java:539)
	at org.springframework.retry.support.RetryTemplate.doExecute(RetryTemplate.java:387)
	at org.springframework.retry.support.RetryTemplate.execute(RetryTemplate.java:255)
	at org.springframework.batch.core.step.item.BatchRetryTemplate.execute(BatchRetryTemplate.java:217)
	at org.springframework.batch.core.step.item.FaultTolerantChunkProcessor.write(FaultTolerantChunkProcessor.java:444)
	at org.springframework.batch.core.step.item.SimpleChunkProcessor.process(SimpleChunkProcessor.java:217)
	at org.springframework.batch.core.step.item.ChunkOrientedTasklet.execute(ChunkOrientedTasklet.java:77)
	at org.springframework.batch.core.step.tasklet.TaskletStep$ChunkTransactionCallback.doInTransaction(TaskletStep.java:407)
	at org.springframework.batch.core.step.tasklet.TaskletStep$ChunkTransactionCallback.doInTransaction(TaskletStep.java:331)
	at org.springframework.transaction.support.TransactionTemplate.execute(TransactionTemplate.java:140)
	at org.springframework.batch.core.step.tasklet.TaskletStep$2.doInChunkContext(TaskletStep.java:273)
	at org.springframework.batch.core.scope.context.StepContextRepeatCallback.doInIteration(StepContextRepeatCallback.java:82)
	at org.springframework.batch.repeat.support.RepeatTemplate.getNextResult(RepeatTemplate.java:375)
	at org.springframework.batch.repeat.support.RepeatTemplate.executeInternal(RepeatTemplate.java:215)
	at org.springframework.batch.repeat.support.RepeatTemplate.iterate(RepeatTemplate.java:145)
	at org.springframework.batch.core.step.tasklet.TaskletStep.doExecute(TaskletStep.java:258)
	at org.springframework.batch.core.step.AbstractStep.execute(AbstractStep.java:208)
	at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at java.base/jdk.internal.reflect.DelegatingMethodAccessorI', '2023-08-29 11:24:26.439000'),
        (148, 3, '등급 이름들 가져오기', 114, '2023-08-29 11:25:00.773000', '2023-08-29 11:25:01.055000', 'COMPLETED', 1, 4, 0, 4, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-29 11:25:01.078000'),
        (149, 1, '등급 재산정', 114, '2023-08-29 11:25:01.478000', null, 'STARTED', 0, 0, 0, 0, 0, 0, 0, 0, 'EXECUTING', '', '2023-08-29 11:25:01.498000'),
        (150, 4, '생일 쿠폰 정보 가져오기', 115, '2023-08-30 01:05:00.592000', '2023-08-30 01:05:01.050000', 'COMPLETED', 2, 1, 0, 1, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-30 01:05:01.073000'),
        (151, 3, '등급 이름들 가져오기', 116, '2023-08-30 01:05:01.072000', '2023-08-30 01:05:01.442000', 'COMPLETED', 1, 4, 0, 4, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-30 01:05:01.471000'),
        (152, 3, '등급 이름들 가져오기', 117, '2023-08-30 01:05:02.226000', '2023-08-30 01:05:02.540000', 'COMPLETED', 1, 4, 0, 4, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-30 01:05:02.562000'),
        (153, 6, '등급 재산정', 116, '2023-08-30 01:05:02.347000', '2023-08-30 01:05:03.329000', 'COMPLETED', 4, 38, 0, 38, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-30 01:05:03.351000'),
        (154, 6, '등급 재산정', 117, '2023-08-30 01:05:03.109000', '2023-08-30 01:05:03.944000', 'COMPLETED', 4, 38, 0, 38, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-30 01:05:03.967000'),
        (155, 3, '등급쿠폰 발급', 116, '2023-08-30 01:05:03.851000', '2023-08-30 01:05:04.040000', 'ABANDONED', 0, 0, 0, 0, 0, 0, 0, 0, 'FAILED', 'org.springframework.batch.item.ItemStreamException: Failed to initialize the reader
	at org.springframework.batch.item.support.AbstractItemCountingItemStreamItemReader.open(AbstractItemCountingItemStreamItemReader.java:153)
	at org.springframework.batch.item.support.AbstractItemCountingItemStreamItemReader$$FastClassBySpringCGLIB$$ebb633d0.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.invokeJoinpoint(CglibAopProxy.java:793)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:163)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:763)
	at org.springframework.aop.support.DelegatingIntroductionInterceptor.doProceed(DelegatingIntroductionInterceptor.java:137)
	at org.springframework.aop.support.DelegatingIntroductionInterceptor.invoke(DelegatingIntroductionInterceptor.java:124)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:186)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:763)
	at org.springframework.aop.framework.CglibAopProxy$DynamicAdvisedInterceptor.intercept(CglibAopProxy.java:708)
	at org.mybatis.spring.batch.MyBatisCursorItemReader$$EnhancerBySpringCGLIB$$f534083c.open(<generated>)
	at org.springframework.batch.item.support.CompositeItemStream.open(CompositeItemStream.java:104)
	at org.springframework.batch.core.step.item.ChunkMonitor.open(ChunkMonitor.java:114)
	at org.springframework.batch.item.support.CompositeItemStream.open(CompositeItemStream.java:104)
	at org.springframework.batch.core.step.tasklet.TaskletStep.open(TaskletStep.java:311)
	at org.springframework.batch.core.step.AbstractStep.execute(AbstractStep.java:205)
	at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at java.base/jdk.internal.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.base/java.lang.reflect.Method.invoke(Method.java:566)
	at org.springframework.aop.support.AopUtils.invokeJoinpointUsingReflection(AopUtils.java:344)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.invokeJoinpoint(ReflectiveMethodInvocation.java:198)
	at org.springframework.aop.fram', '2023-08-30 01:05:04.264000'),
        (156, 3, '등급쿠폰 발급', 117, '2023-08-30 01:05:04.684000', '2023-08-30 01:05:04.876000', 'ABANDONED', 0, 0, 0, 0, 0, 0, 0, 0, 'FAILED', 'org.springframework.batch.item.ItemStreamException: Failed to initialize the reader
	at org.springframework.batch.item.support.AbstractItemCountingItemStreamItemReader.open(AbstractItemCountingItemStreamItemReader.java:153)
	at org.springframework.batch.item.support.AbstractItemCountingItemStreamItemReader$$FastClassBySpringCGLIB$$ebb633d0.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.invokeJoinpoint(CglibAopProxy.java:793)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:163)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:763)
	at org.springframework.aop.support.DelegatingIntroductionInterceptor.doProceed(DelegatingIntroductionInterceptor.java:137)
	at org.springframework.aop.support.DelegatingIntroductionInterceptor.invoke(DelegatingIntroductionInterceptor.java:124)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:186)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:763)
	at org.springframework.aop.framework.CglibAopProxy$DynamicAdvisedInterceptor.intercept(CglibAopProxy.java:708)
	at org.mybatis.spring.batch.MyBatisCursorItemReader$$EnhancerBySpringCGLIB$$f534083c.open(<generated>)
	at org.springframework.batch.item.support.CompositeItemStream.open(CompositeItemStream.java:104)
	at org.springframework.batch.core.step.item.ChunkMonitor.open(ChunkMonitor.java:114)
	at org.springframework.batch.item.support.CompositeItemStream.open(CompositeItemStream.java:104)
	at org.springframework.batch.core.step.tasklet.TaskletStep.open(TaskletStep.java:311)
	at org.springframework.batch.core.step.AbstractStep.execute(AbstractStep.java:205)
	at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at java.base/jdk.internal.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.base/java.lang.reflect.Method.invoke(Method.java:566)
	at org.springframework.aop.support.AopUtils.invokeJoinpointUsingReflection(AopUtils.java:344)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.invokeJoinpoint(ReflectiveMethodInvocation.java:198)
	at org.springframework.aop.fram', '2023-08-30 01:05:05.033000'),
        (157, 3, 'sendFailIssueRankCouponStep', 116, '2023-08-30 01:05:04.785000', '2023-08-30 01:05:06.303000', 'FAILED', 1, 0, 0, 0, 0, 0, 0, 0, 'FAILED', '', '2023-08-30 01:05:06.326000'),
        (158, 3, 'sendFailIssueRankCouponStep', 117, '2023-08-30 01:05:05.444000', '2023-08-30 01:05:06.771000', 'FAILED', 1, 0, 0, 0, 0, 0, 0, 0, 'FAILED', '', '2023-08-30 01:05:06.807000'),
        (159, 3, '휴면될 회원리스트 가져오기', 118, '2023-08-30 01:05:08.076000', '2023-08-30 01:05:08.448000', 'COMPLETED', 1, 0, 0, 0, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-30 01:05:08.472000'),
        (160, 3, 'statusChangeSuccessStep', 118, '2023-08-30 01:05:08.979000', '2023-08-30 01:05:09.513000', 'COMPLETED', 1, 0, 0, 0, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-30 01:05:09.560000'),
        (161, 4, '생일 쿠폰 정보 가져오기', 119, '2023-08-30 01:11:22.189000', '2023-08-30 01:11:22.660000', 'COMPLETED', 2, 1, 0, 1, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-30 01:11:22.682000'),
        (162, 3, '등급 이름들 가져오기', 120, '2023-08-30 01:11:23.862000', '2023-08-30 01:11:24.393000', 'COMPLETED', 1, 4, 0, 4, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-30 01:11:24.416000'),
        (163, 6, '등급 재산정', 120, '2023-08-30 01:11:24.881000', '2023-08-30 01:11:25.764000', 'COMPLETED', 4, 38, 0, 38, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-30 01:11:25.815000'),
        (164, 3, '등급쿠폰 발급', 120, '2023-08-30 01:11:26.334000', '2023-08-30 01:11:26.549000', 'ABANDONED', 0, 0, 0, 0, 0, 0, 0, 0, 'FAILED', 'org.springframework.batch.item.ItemStreamException: Failed to initialize the reader
	at org.springframework.batch.item.support.AbstractItemCountingItemStreamItemReader.open(AbstractItemCountingItemStreamItemReader.java:153)
	at org.springframework.batch.item.support.AbstractItemCountingItemStreamItemReader$$FastClassBySpringCGLIB$$ebb633d0.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.invokeJoinpoint(CglibAopProxy.java:793)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:163)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:763)
	at org.springframework.aop.support.DelegatingIntroductionInterceptor.doProceed(DelegatingIntroductionInterceptor.java:137)
	at org.springframework.aop.support.DelegatingIntroductionInterceptor.invoke(DelegatingIntroductionInterceptor.java:124)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:186)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:763)
	at org.springframework.aop.framework.CglibAopProxy$DynamicAdvisedInterceptor.intercept(CglibAopProxy.java:708)
	at org.mybatis.spring.batch.MyBatisCursorItemReader$$EnhancerBySpringCGLIB$$4d387eda.open(<generated>)
	at org.springframework.batch.item.support.CompositeItemStream.open(CompositeItemStream.java:104)
	at org.springframework.batch.core.step.item.ChunkMonitor.open(ChunkMonitor.java:114)
	at org.springframework.batch.item.support.CompositeItemStream.open(CompositeItemStream.java:104)
	at org.springframework.batch.core.step.tasklet.TaskletStep.open(TaskletStep.java:311)
	at org.springframework.batch.core.step.AbstractStep.execute(AbstractStep.java:205)
	at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at java.base/jdk.internal.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.base/java.lang.reflect.Method.invoke(Method.java:566)
	at org.springframework.aop.support.AopUtils.invokeJoinpointUsingReflection(AopUtils.java:344)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.invokeJoinpoint(ReflectiveMethodInvocation.java:198)
	at org.springframework.aop.fram', '2023-08-30 01:11:26.930000'),
        (165, 3, 'sendFailIssueRankCouponStep', 120, '2023-08-30 01:11:27.540000', '2023-08-30 01:11:29.061000', 'FAILED', 1, 0, 0, 0, 0, 0, 0, 0, 'FAILED', '', '2023-08-30 01:11:29.084000'),
        (166, 4, '생일 쿠폰 정보 가져오기', 122, '2023-08-30 01:14:46.513000', '2023-08-30 01:14:47.035000', 'COMPLETED', 2, 1, 0, 1, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-30 01:14:47.057000'),
        (167, 3, '등급 이름들 가져오기', 123, '2023-08-30 01:14:48.163000', '2023-08-30 01:14:48.499000', 'COMPLETED', 1, 4, 0, 4, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-30 01:14:48.524000'),
        (168, 6, '등급 재산정', 123, '2023-08-30 01:14:48.997000', '2023-08-30 01:14:49.907000', 'COMPLETED', 4, 38, 0, 38, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-30 01:14:49.933000'),
        (169, 3, '등급쿠폰 발급', 123, '2023-08-30 01:14:50.474000', '2023-08-30 01:14:50.636000', 'ABANDONED', 0, 0, 0, 0, 0, 0, 0, 0, 'FAILED', 'org.springframework.batch.item.ItemStreamException: Failed to initialize the reader
	at org.springframework.batch.item.support.AbstractItemCountingItemStreamItemReader.open(AbstractItemCountingItemStreamItemReader.java:153)
	at org.springframework.batch.item.support.AbstractItemCountingItemStreamItemReader$$FastClassBySpringCGLIB$$ebb633d0.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.invokeJoinpoint(CglibAopProxy.java:793)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:163)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:763)
	at org.springframework.aop.support.DelegatingIntroductionInterceptor.doProceed(DelegatingIntroductionInterceptor.java:137)
	at org.springframework.aop.support.DelegatingIntroductionInterceptor.invoke(DelegatingIntroductionInterceptor.java:124)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:186)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:763)
	at org.springframework.aop.framework.CglibAopProxy$DynamicAdvisedInterceptor.intercept(CglibAopProxy.java:708)
	at org.mybatis.spring.batch.MyBatisCursorItemReader$$EnhancerBySpringCGLIB$$f534083c.open(<generated>)
	at org.springframework.batch.item.support.CompositeItemStream.open(CompositeItemStream.java:104)
	at org.springframework.batch.core.step.item.ChunkMonitor.open(ChunkMonitor.java:114)
	at org.springframework.batch.item.support.CompositeItemStream.open(CompositeItemStream.java:104)
	at org.springframework.batch.core.step.tasklet.TaskletStep.open(TaskletStep.java:311)
	at org.springframework.batch.core.step.AbstractStep.execute(AbstractStep.java:205)
	at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at java.base/jdk.internal.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.base/java.lang.reflect.Method.invoke(Method.java:566)
	at org.springframework.aop.support.AopUtils.invokeJoinpointUsingReflection(AopUtils.java:344)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.invokeJoinpoint(ReflectiveMethodInvocation.java:198)
	at org.springframework.aop.fram', '2023-08-30 01:14:51.016000'),
        (170, 3, 'sendFailIssueRankCouponStep', 123, '2023-08-30 01:14:51.426000', '2023-08-30 01:14:52.827000', 'FAILED', 1, 0, 0, 0, 0, 0, 0, 0, 'FAILED', '', '2023-08-30 01:14:52.850000'),
        (171, 3, '등급 이름들 가져오기', 125, '2023-08-30 01:15:01.519000', '2023-08-30 01:15:01.898000', 'COMPLETED', 1, 4, 0, 4, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-30 01:15:01.920000'),
        (172, 6, '등급 재산정', 125, '2023-08-30 01:15:02.427000', '2023-08-30 01:15:03.319000', 'COMPLETED', 4, 38, 0, 38, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-30 01:15:03.343000'),
        (173, 3, '등급쿠폰 발급', 125, '2023-08-30 01:15:03.836000', '2023-08-30 01:15:04.001000', 'ABANDONED', 0, 0, 0, 0, 0, 0, 0, 0, 'FAILED', 'org.springframework.batch.item.ItemStreamException: Failed to initialize the reader
	at org.springframework.batch.item.support.AbstractItemCountingItemStreamItemReader.open(AbstractItemCountingItemStreamItemReader.java:153)
	at org.springframework.batch.item.support.AbstractItemCountingItemStreamItemReader$$FastClassBySpringCGLIB$$ebb633d0.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.invokeJoinpoint(CglibAopProxy.java:793)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:163)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:763)
	at org.springframework.aop.support.DelegatingIntroductionInterceptor.doProceed(DelegatingIntroductionInterceptor.java:137)
	at org.springframework.aop.support.DelegatingIntroductionInterceptor.invoke(DelegatingIntroductionInterceptor.java:124)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:186)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:763)
	at org.springframework.aop.framework.CglibAopProxy$DynamicAdvisedInterceptor.intercept(CglibAopProxy.java:708)
	at org.mybatis.spring.batch.MyBatisCursorItemReader$$EnhancerBySpringCGLIB$$f534083c.open(<generated>)
	at org.springframework.batch.item.support.CompositeItemStream.open(CompositeItemStream.java:104)
	at org.springframework.batch.core.step.item.ChunkMonitor.open(ChunkMonitor.java:114)
	at org.springframework.batch.item.support.CompositeItemStream.open(CompositeItemStream.java:104)
	at org.springframework.batch.core.step.tasklet.TaskletStep.open(TaskletStep.java:311)
	at org.springframework.batch.core.step.AbstractStep.execute(AbstractStep.java:205)
	at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at java.base/jdk.internal.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.base/java.lang.reflect.Method.invoke(Method.java:566)
	at org.springframework.aop.support.AopUtils.invokeJoinpointUsingReflection(AopUtils.java:344)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.invokeJoinpoint(ReflectiveMethodInvocation.java:198)
	at org.springframework.aop.fram', '2023-08-30 01:15:04.167000'),
        (174, 3, 'sendFailIssueRankCouponStep', 125, '2023-08-30 01:15:04.616000', '2023-08-30 01:15:05.978000', 'FAILED', 1, 0, 0, 0, 0, 0, 0, 0, 'FAILED', '', '2023-08-30 01:15:06'),
        (175, 4, '생일 쿠폰 정보 가져오기', 126, '2023-08-30 01:17:25.883000', '2023-08-30 01:17:26.362000', 'COMPLETED', 2, 1, 0, 1, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-30 01:17:26.387000'),
        (176, 3, '등급 이름들 가져오기', 127, '2023-08-30 01:17:27.563000', '2023-08-30 01:17:27.886000', 'COMPLETED', 1, 4, 0, 4, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-30 01:17:27.909000'),
        (177, 6, '등급 재산정', 127, '2023-08-30 01:17:28.352000', '2023-08-30 01:17:29.195000', 'COMPLETED', 4, 38, 0, 38, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-30 01:17:29.219000'),
        (178, 3, '등급쿠폰 발급', 127, '2023-08-30 01:17:29.688000', '2023-08-30 01:17:29.858000', 'ABANDONED', 0, 0, 0, 0, 0, 0, 0, 0, 'FAILED', 'org.springframework.batch.item.ItemStreamException: Failed to initialize the reader
	at org.springframework.batch.item.support.AbstractItemCountingItemStreamItemReader.open(AbstractItemCountingItemStreamItemReader.java:153)
	at org.springframework.batch.item.support.AbstractItemCountingItemStreamItemReader$$FastClassBySpringCGLIB$$ebb633d0.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.invokeJoinpoint(CglibAopProxy.java:793)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:163)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:763)
	at org.springframework.aop.support.DelegatingIntroductionInterceptor.doProceed(DelegatingIntroductionInterceptor.java:137)
	at org.springframework.aop.support.DelegatingIntroductionInterceptor.invoke(DelegatingIntroductionInterceptor.java:124)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:186)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:763)
	at org.springframework.aop.framework.CglibAopProxy$DynamicAdvisedInterceptor.intercept(CglibAopProxy.java:708)
	at org.mybatis.spring.batch.MyBatisCursorItemReader$$EnhancerBySpringCGLIB$$f534083c.open(<generated>)
	at org.springframework.batch.item.support.CompositeItemStream.open(CompositeItemStream.java:104)
	at org.springframework.batch.core.step.item.ChunkMonitor.open(ChunkMonitor.java:114)
	at org.springframework.batch.item.support.CompositeItemStream.open(CompositeItemStream.java:104)
	at org.springframework.batch.core.step.tasklet.TaskletStep.open(TaskletStep.java:311)
	at org.springframework.batch.core.step.AbstractStep.execute(AbstractStep.java:205)
	at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at java.base/jdk.internal.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.base/java.lang.reflect.Method.invoke(Method.java:566)
	at org.springframework.aop.support.AopUtils.invokeJoinpointUsingReflection(AopUtils.java:344)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.invokeJoinpoint(ReflectiveMethodInvocation.java:198)
	at org.springframework.aop.fram', '2023-08-30 01:17:30.020000'),
        (179, 3, 'sendFailIssueRankCouponStep', 127, '2023-08-30 01:17:30.428000', '2023-08-30 01:17:31.951000', 'FAILED', 1, 0, 0, 0, 0, 0, 0, 0, 'FAILED', '', '2023-08-30 01:17:31.976000'),
        (180, 4, '생일 쿠폰 정보 가져오기', 129, '2023-08-30 01:19:47.315000', '2023-08-30 01:19:47.732000', 'COMPLETED', 2, 1, 0, 1, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-30 01:19:47.759000'),
        (181, 3, '등급 이름들 가져오기', 130, '2023-08-30 01:19:48.945000', '2023-08-30 01:19:49.268000', 'COMPLETED', 1, 4, 0, 4, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-30 01:19:49.289000'),
        (182, 6, '등급 재산정', 130, '2023-08-30 01:19:49.773000', '2023-08-30 01:19:50.616000', 'COMPLETED', 4, 38, 0, 38, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-30 01:19:50.645000'),
        (183, 3, '등급쿠폰 발급', 130, '2023-08-30 01:19:51.091000', '2023-08-30 01:19:51.256000', 'ABANDONED', 0, 0, 0, 0, 0, 0, 0, 0, 'FAILED', 'org.springframework.batch.item.ItemStreamException: Failed to initialize the reader
	at org.springframework.batch.item.support.AbstractItemCountingItemStreamItemReader.open(AbstractItemCountingItemStreamItemReader.java:153)
	at org.springframework.batch.item.support.AbstractItemCountingItemStreamItemReader$$FastClassBySpringCGLIB$$ebb633d0.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.invokeJoinpoint(CglibAopProxy.java:793)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:163)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:763)
	at org.springframework.aop.support.DelegatingIntroductionInterceptor.doProceed(DelegatingIntroductionInterceptor.java:137)
	at org.springframework.aop.support.DelegatingIntroductionInterceptor.invoke(DelegatingIntroductionInterceptor.java:124)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:186)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:763)
	at org.springframework.aop.framework.CglibAopProxy$DynamicAdvisedInterceptor.intercept(CglibAopProxy.java:708)
	at org.mybatis.spring.batch.MyBatisCursorItemReader$$EnhancerBySpringCGLIB$$769d749b.open(<generated>)
	at org.springframework.batch.item.support.CompositeItemStream.open(CompositeItemStream.java:104)
	at org.springframework.batch.core.step.item.ChunkMonitor.open(ChunkMonitor.java:114)
	at org.springframework.batch.item.support.CompositeItemStream.open(CompositeItemStream.java:104)
	at org.springframework.batch.core.step.tasklet.TaskletStep.open(TaskletStep.java:311)
	at org.springframework.batch.core.step.AbstractStep.execute(AbstractStep.java:205)
	at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at java.base/jdk.internal.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.base/java.lang.reflect.Method.invoke(Method.java:566)
	at org.springframework.aop.support.AopUtils.invokeJoinpointUsingReflection(AopUtils.java:344)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.invokeJoinpoint(ReflectiveMethodInvocation.java:198)
	at org.springframework.aop.fram', '2023-08-30 01:19:51.424000'),
        (184, 3, 'sendFailIssueRankCouponStep', 130, '2023-08-30 01:19:51.795000', '2023-08-30 01:19:53.125000', 'FAILED', 1, 0, 0, 0, 0, 0, 0, 0, 'FAILED', '', '2023-08-30 01:19:53.147000'),
        (185, 4, '생일 쿠폰 정보 가져오기', 133, '2023-08-30 01:20:25.125000', '2023-08-30 01:20:25.579000', 'COMPLETED', 2, 1, 0, 1, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-30 01:20:25.603000'),
        (186, 3, '등급 이름들 가져오기', 134, '2023-08-30 01:20:26.765000', '2023-08-30 01:20:27.075000', 'COMPLETED', 1, 4, 0, 4, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-30 01:20:27.116000'),
        (187, 6, '등급 재산정', 134, '2023-08-30 01:20:27.572000', '2023-08-30 01:20:28.352000', 'COMPLETED', 4, 38, 0, 38, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-30 01:20:28.376000'),
        (188, 3, '등급쿠폰 발급', 134, '2023-08-30 01:20:28.857000', '2023-08-30 01:20:29.044000', 'ABANDONED', 0, 0, 0, 0, 0, 0, 0, 0, 'FAILED', 'org.springframework.batch.item.ItemStreamException: Failed to initialize the reader
	at org.springframework.batch.item.support.AbstractItemCountingItemStreamItemReader.open(AbstractItemCountingItemStreamItemReader.java:153)
	at org.springframework.batch.item.support.AbstractItemCountingItemStreamItemReader$$FastClassBySpringCGLIB$$ebb633d0.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.invokeJoinpoint(CglibAopProxy.java:793)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:163)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:763)
	at org.springframework.aop.support.DelegatingIntroductionInterceptor.doProceed(DelegatingIntroductionInterceptor.java:137)
	at org.springframework.aop.support.DelegatingIntroductionInterceptor.invoke(DelegatingIntroductionInterceptor.java:124)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:186)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:763)
	at org.springframework.aop.framework.CglibAopProxy$DynamicAdvisedInterceptor.intercept(CglibAopProxy.java:708)
	at org.mybatis.spring.batch.MyBatisCursorItemReader$$EnhancerBySpringCGLIB$$769d749b.open(<generated>)
	at org.springframework.batch.item.support.CompositeItemStream.open(CompositeItemStream.java:104)
	at org.springframework.batch.core.step.item.ChunkMonitor.open(ChunkMonitor.java:114)
	at org.springframework.batch.item.support.CompositeItemStream.open(CompositeItemStream.java:104)
	at org.springframework.batch.core.step.tasklet.TaskletStep.open(TaskletStep.java:311)
	at org.springframework.batch.core.step.AbstractStep.execute(AbstractStep.java:205)
	at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at java.base/jdk.internal.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.base/java.lang.reflect.Method.invoke(Method.java:566)
	at org.springframework.aop.support.AopUtils.invokeJoinpointUsingReflection(AopUtils.java:344)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.invokeJoinpoint(ReflectiveMethodInvocation.java:198)
	at org.springframework.aop.fram', '2023-08-30 01:20:29.206000'),
        (189, 3, 'sendFailIssueRankCouponStep', 134, '2023-08-30 01:20:29.630000', '2023-08-30 01:20:30.982000', 'FAILED', 1, 0, 0, 0, 0, 0, 0, 0, 'FAILED', '', '2023-08-30 01:20:31.018000'),
        (190, 4, '생일 쿠폰 정보 가져오기', 136, '2023-08-30 01:23:39.795000', '2023-08-30 01:23:40.238000', 'COMPLETED', 2, 1, 0, 1, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-30 01:23:40.261000'),
        (191, 3, '등급 이름들 가져오기', 137, '2023-08-30 01:23:41.375000', '2023-08-30 01:23:41.697000', 'COMPLETED', 1, 4, 0, 4, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-30 01:23:41.726000'),
        (192, 6, '등급 재산정', 137, '2023-08-30 01:23:42.180000', '2023-08-30 01:23:42.941000', 'COMPLETED', 4, 38, 0, 38, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-30 01:23:42.964000'),
        (193, 3, '등급쿠폰 발급', 137, '2023-08-30 01:23:43.400000', '2023-08-30 01:23:43.551000', 'ABANDONED', 0, 0, 0, 0, 0, 0, 0, 0, 'FAILED', 'org.springframework.batch.item.ItemStreamException: Failed to initialize the reader
	at org.springframework.batch.item.support.AbstractItemCountingItemStreamItemReader.open(AbstractItemCountingItemStreamItemReader.java:153)
	at org.springframework.batch.item.support.AbstractItemCountingItemStreamItemReader$$FastClassBySpringCGLIB$$ebb633d0.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.invokeJoinpoint(CglibAopProxy.java:793)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:163)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:763)
	at org.springframework.aop.support.DelegatingIntroductionInterceptor.doProceed(DelegatingIntroductionInterceptor.java:137)
	at org.springframework.aop.support.DelegatingIntroductionInterceptor.invoke(DelegatingIntroductionInterceptor.java:124)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:186)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:763)
	at org.springframework.aop.framework.CglibAopProxy$DynamicAdvisedInterceptor.intercept(CglibAopProxy.java:708)
	at org.mybatis.spring.batch.MyBatisCursorItemReader$$EnhancerBySpringCGLIB$$769d749b.open(<generated>)
	at org.springframework.batch.item.support.CompositeItemStream.open(CompositeItemStream.java:104)
	at org.springframework.batch.core.step.item.ChunkMonitor.open(ChunkMonitor.java:114)
	at org.springframework.batch.item.support.CompositeItemStream.open(CompositeItemStream.java:104)
	at org.springframework.batch.core.step.tasklet.TaskletStep.open(TaskletStep.java:311)
	at org.springframework.batch.core.step.AbstractStep.execute(AbstractStep.java:205)
	at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at java.base/jdk.internal.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.base/java.lang.reflect.Method.invoke(Method.java:566)
	at org.springframework.aop.support.AopUtils.invokeJoinpointUsingReflection(AopUtils.java:344)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.invokeJoinpoint(ReflectiveMethodInvocation.java:198)
	at org.springframework.aop.fram', '2023-08-30 01:23:43.705000'),
        (194, 3, 'sendFailIssueRankCouponStep', 137, '2023-08-30 01:23:44.085000', '2023-08-30 01:23:45.649000', 'FAILED', 1, 0, 0, 0, 0, 0, 0, 0, 'FAILED', '', '2023-08-30 01:23:45.676000'),
        (195, 4, '생일 쿠폰 정보 가져오기', 139, '2023-08-30 01:29:49.214000', '2023-08-30 01:29:49.681000', 'COMPLETED', 2, 1, 0, 1, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-30 01:29:49.717000'),
        (196, 3, '등급 이름들 가져오기', 140, '2023-08-30 01:29:50.883000', '2023-08-30 01:29:51.218000', 'COMPLETED', 1, 4, 0, 4, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-30 01:29:51.253000'),
        (197, 6, '등급 재산정', 140, '2023-08-30 01:29:51.741000', '2023-08-30 01:29:52.550000', 'COMPLETED', 4, 38, 0, 38, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-30 01:29:52.577000'),
        (198, 3, '등급쿠폰 발급', 140, '2023-08-30 01:29:53.047000', '2023-08-30 01:29:53.218000', 'ABANDONED', 0, 0, 0, 0, 0, 0, 0, 0, 'FAILED', 'org.springframework.batch.item.ItemStreamException: Failed to initialize the reader
	at org.springframework.batch.item.support.AbstractItemCountingItemStreamItemReader.open(AbstractItemCountingItemStreamItemReader.java:153)
	at org.springframework.batch.item.support.AbstractItemCountingItemStreamItemReader$$FastClassBySpringCGLIB$$ebb633d0.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.invokeJoinpoint(CglibAopProxy.java:793)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:163)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:763)
	at org.springframework.aop.support.DelegatingIntroductionInterceptor.doProceed(DelegatingIntroductionInterceptor.java:137)
	at org.springframework.aop.support.DelegatingIntroductionInterceptor.invoke(DelegatingIntroductionInterceptor.java:124)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:186)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:763)
	at org.springframework.aop.framework.CglibAopProxy$DynamicAdvisedInterceptor.intercept(CglibAopProxy.java:708)
	at org.mybatis.spring.batch.MyBatisCursorItemReader$$EnhancerBySpringCGLIB$$769d749b.open(<generated>)
	at org.springframework.batch.item.support.CompositeItemStream.open(CompositeItemStream.java:104)
	at org.springframework.batch.core.step.item.ChunkMonitor.open(ChunkMonitor.java:114)
	at org.springframework.batch.item.support.CompositeItemStream.open(CompositeItemStream.java:104)
	at org.springframework.batch.core.step.tasklet.TaskletStep.open(TaskletStep.java:311)
	at org.springframework.batch.core.step.AbstractStep.execute(AbstractStep.java:205)
	at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at java.base/jdk.internal.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.base/java.lang.reflect.Method.invoke(Method.java:566)
	at org.springframework.aop.support.AopUtils.invokeJoinpointUsingReflection(AopUtils.java:344)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.invokeJoinpoint(ReflectiveMethodInvocation.java:198)
	at org.springframework.aop.fram', '2023-08-30 01:29:53.368000'),
        (199, 3, 'sendFailIssueRankCouponStep', 140, '2023-08-30 01:29:53.773000', '2023-08-30 01:29:55.255000', 'FAILED', 1, 0, 0, 0, 0, 0, 0, 0, 'FAILED', '', '2023-08-30 01:29:55.278000'),
        (200, 3, '등급 이름들 가져오기', 142, '2023-08-30 01:30:00.976000', '2023-08-30 01:30:01.300000', 'COMPLETED', 1, 4, 0, 4, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-30 01:30:01.323000'),
        (201, 6, '등급 재산정', 142, '2023-08-30 01:30:01.802000', '2023-08-30 01:30:02.613000', 'COMPLETED', 4, 38, 0, 38, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-30 01:30:02.636000'),
        (202, 3, '등급쿠폰 발급', 142, '2023-08-30 01:30:03.154000', '2023-08-30 01:30:03.343000', 'ABANDONED', 0, 0, 0, 0, 0, 0, 0, 0, 'FAILED', 'org.springframework.batch.item.ItemStreamException: Failed to initialize the reader
	at org.springframework.batch.item.support.AbstractItemCountingItemStreamItemReader.open(AbstractItemCountingItemStreamItemReader.java:153)
	at org.springframework.batch.item.support.AbstractItemCountingItemStreamItemReader$$FastClassBySpringCGLIB$$ebb633d0.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.invokeJoinpoint(CglibAopProxy.java:793)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:163)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:763)
	at org.springframework.aop.support.DelegatingIntroductionInterceptor.doProceed(DelegatingIntroductionInterceptor.java:137)
	at org.springframework.aop.support.DelegatingIntroductionInterceptor.invoke(DelegatingIntroductionInterceptor.java:124)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:186)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:763)
	at org.springframework.aop.framework.CglibAopProxy$DynamicAdvisedInterceptor.intercept(CglibAopProxy.java:708)
	at org.mybatis.spring.batch.MyBatisCursorItemReader$$EnhancerBySpringCGLIB$$769d749b.open(<generated>)
	at org.springframework.batch.item.support.CompositeItemStream.open(CompositeItemStream.java:104)
	at org.springframework.batch.core.step.item.ChunkMonitor.open(ChunkMonitor.java:114)
	at org.springframework.batch.item.support.CompositeItemStream.open(CompositeItemStream.java:104)
	at org.springframework.batch.core.step.tasklet.TaskletStep.open(TaskletStep.java:311)
	at org.springframework.batch.core.step.AbstractStep.execute(AbstractStep.java:205)
	at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at java.base/jdk.internal.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.base/java.lang.reflect.Method.invoke(Method.java:566)
	at org.springframework.aop.support.AopUtils.invokeJoinpointUsingReflection(AopUtils.java:344)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.invokeJoinpoint(ReflectiveMethodInvocation.java:198)
	at org.springframework.aop.fram', '2023-08-30 01:30:03.519000'),
        (203, 3, 'sendFailIssueRankCouponStep', 142, '2023-08-30 01:30:03.958000', '2023-08-30 01:30:05.318000', 'FAILED', 1, 0, 0, 0, 0, 0, 0, 0, 'FAILED', '', '2023-08-30 01:30:05.353000'),
        (204, 4, '생일 쿠폰 정보 가져오기', 143, '2023-08-30 01:31:11.955000', '2023-08-30 01:31:12.441000', 'COMPLETED', 2, 1, 0, 1, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-30 01:31:12.461000'),
        (205, 3, '생일쿠폰 발급', 143, '2023-08-30 01:31:12.887000', '2023-08-30 01:31:13.234000', 'COMPLETED', 1, 0, 0, 0, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-30 01:31:13.258000'),
        (206, 3, '등급 이름들 가져오기', 144, '2023-08-30 01:31:14.364000', '2023-08-30 01:31:14.710000', 'COMPLETED', 1, 4, 0, 4, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-30 01:31:14.731000'),
        (207, 6, '등급 재산정', 144, '2023-08-30 01:31:15.229000', '2023-08-30 01:31:16.032000', 'COMPLETED', 4, 38, 0, 38, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-30 01:31:16.055000'),
        (208, 3, '등급쿠폰 발급', 144, '2023-08-30 01:31:16.497000', '2023-08-30 01:31:16.661000', 'ABANDONED', 0, 0, 0, 0, 0, 0, 0, 0, 'FAILED', 'org.springframework.batch.item.ItemStreamException: Failed to initialize the reader
	at org.springframework.batch.item.support.AbstractItemCountingItemStreamItemReader.open(AbstractItemCountingItemStreamItemReader.java:153)
	at org.springframework.batch.item.support.AbstractItemCountingItemStreamItemReader$$FastClassBySpringCGLIB$$ebb633d0.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.invokeJoinpoint(CglibAopProxy.java:793)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:163)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:763)
	at org.springframework.aop.support.DelegatingIntroductionInterceptor.doProceed(DelegatingIntroductionInterceptor.java:137)
	at org.springframework.aop.support.DelegatingIntroductionInterceptor.invoke(DelegatingIntroductionInterceptor.java:124)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:186)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:763)
	at org.springframework.aop.framework.CglibAopProxy$DynamicAdvisedInterceptor.intercept(CglibAopProxy.java:708)
	at org.mybatis.spring.batch.MyBatisCursorItemReader$$EnhancerBySpringCGLIB$$828ee49e.open(<generated>)
	at org.springframework.batch.item.support.CompositeItemStream.open(CompositeItemStream.java:104)
	at org.springframework.batch.core.step.item.ChunkMonitor.open(ChunkMonitor.java:114)
	at org.springframework.batch.item.support.CompositeItemStream.open(CompositeItemStream.java:104)
	at org.springframework.batch.core.step.tasklet.TaskletStep.open(TaskletStep.java:311)
	at org.springframework.batch.core.step.AbstractStep.execute(AbstractStep.java:205)
	at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at java.base/jdk.internal.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.base/java.lang.reflect.Method.invoke(Method.java:566)
	at org.springframework.aop.support.AopUtils.invokeJoinpointUsingReflection(AopUtils.java:344)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.invokeJoinpoint(ReflectiveMethodInvocation.java:198)
	at org.springframework.aop.fram', '2023-08-30 01:31:16.809000'),
        (209, 3, 'sendFailIssueRankCouponStep', 144, '2023-08-30 01:31:17.186000', '2023-08-30 01:31:18.534000', 'FAILED', 1, 0, 0, 0, 0, 0, 0, 0, 'FAILED', '', '2023-08-30 01:31:18.555000'),
        (210, 4, '생일 쿠폰 정보 가져오기', 145, '2023-08-30 01:32:08.250000', '2023-08-30 01:32:08.656000', 'COMPLETED', 2, 1, 0, 1, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-30 01:32:08.679000'),
        (211, 3, '생일쿠폰 발급', 145, '2023-08-30 01:32:09.168000', '2023-08-30 01:32:09.513000', 'COMPLETED', 1, 0, 0, 0, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-30 01:32:09.534000'),
        (212, 3, '생일 쿠폰 발급 완료', 145, '2023-08-30 01:32:10.010000', '2023-08-30 01:32:10.311000', 'COMPLETED', 1, 0, 0, 0, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-30 01:32:10.333000'),
        (213, 3, '등급 이름들 가져오기', 146, '2023-08-30 01:32:11.457000', '2023-08-30 01:32:11.790000', 'COMPLETED', 1, 4, 0, 4, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-30 01:32:11.813000'),
        (214, 6, '등급 재산정', 146, '2023-08-30 01:32:12.341000', '2023-08-30 01:32:13.126000', 'COMPLETED', 4, 38, 0, 38, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-30 01:32:13.149000'),
        (215, 3, '등급쿠폰 발급', 146, '2023-08-30 01:32:13.620000', '2023-08-30 01:32:13.785000', 'ABANDONED', 0, 0, 0, 0, 0, 0, 0, 0, 'FAILED', 'org.springframework.batch.item.ItemStreamException: Failed to initialize the reader
	at org.springframework.batch.item.support.AbstractItemCountingItemStreamItemReader.open(AbstractItemCountingItemStreamItemReader.java:153)
	at org.springframework.batch.item.support.AbstractItemCountingItemStreamItemReader$$FastClassBySpringCGLIB$$ebb633d0.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.invokeJoinpoint(CglibAopProxy.java:793)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:163)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:763)
	at org.springframework.aop.support.DelegatingIntroductionInterceptor.doProceed(DelegatingIntroductionInterceptor.java:137)
	at org.springframework.aop.support.DelegatingIntroductionInterceptor.invoke(DelegatingIntroductionInterceptor.java:124)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:186)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:763)
	at org.springframework.aop.framework.CglibAopProxy$DynamicAdvisedInterceptor.intercept(CglibAopProxy.java:708)
	at org.mybatis.spring.batch.MyBatisCursorItemReader$$EnhancerBySpringCGLIB$$460665e0.open(<generated>)
	at org.springframework.batch.item.support.CompositeItemStream.open(CompositeItemStream.java:104)
	at org.springframework.batch.core.step.item.ChunkMonitor.open(ChunkMonitor.java:114)
	at org.springframework.batch.item.support.CompositeItemStream.open(CompositeItemStream.java:104)
	at org.springframework.batch.core.step.tasklet.TaskletStep.open(TaskletStep.java:311)
	at org.springframework.batch.core.step.AbstractStep.execute(AbstractStep.java:205)
	at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at java.base/jdk.internal.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.base/java.lang.reflect.Method.invoke(Method.java:566)
	at org.springframework.aop.support.AopUtils.invokeJoinpointUsingReflection(AopUtils.java:344)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.invokeJoinpoint(ReflectiveMethodInvocation.java:198)
	at org.springframework.aop.fram', '2023-08-30 01:32:13.950000'),
        (216, 3, 'sendFailIssueRankCouponStep', 146, '2023-08-30 01:32:14.354000', '2023-08-30 01:32:15.773000', 'FAILED', 1, 0, 0, 0, 0, 0, 0, 0, 'FAILED', '', '2023-08-30 01:32:15.796000'),
        (217, 4, '생일 쿠폰 정보 가져오기', 148, '2023-08-30 01:35:46.844000', '2023-08-30 01:35:47.292000', 'COMPLETED', 2, 1, 0, 1, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-30 01:35:47.315000'),
        (218, 3, '생일쿠폰 발급', 148, '2023-08-30 01:35:47.788000', '2023-08-30 01:35:48.108000', 'COMPLETED', 1, 0, 0, 0, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-30 01:35:48.131000'),
        (219, 3, '생일 쿠폰 발급 완료', 148, '2023-08-30 01:35:48.600000', '2023-08-30 01:35:48.888000', 'COMPLETED', 1, 0, 0, 0, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-30 01:35:48.911000'),
        (220, 3, '등급 이름들 가져오기', 149, '2023-08-30 01:35:50.116000', '2023-08-30 01:35:50.430000', 'COMPLETED', 1, 4, 0, 4, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-30 01:35:50.455000'),
        (221, 6, '등급 재산정', 149, '2023-08-30 01:35:50.928000', '2023-08-30 01:35:51.768000', 'COMPLETED', 4, 38, 0, 38, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-30 01:35:51.797000'),
        (222, 3, '등급쿠폰 발급', 149, '2023-08-30 01:35:52.264000', '2023-08-30 01:35:52.431000', 'ABANDONED', 0, 0, 0, 0, 0, 0, 0, 0, 'FAILED', 'org.springframework.batch.item.ItemStreamException: Failed to initialize the reader
	at org.springframework.batch.item.support.AbstractItemCountingItemStreamItemReader.open(AbstractItemCountingItemStreamItemReader.java:153)
	at org.springframework.batch.item.support.AbstractItemCountingItemStreamItemReader$$FastClassBySpringCGLIB$$ebb633d0.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.invokeJoinpoint(CglibAopProxy.java:793)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:163)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:763)
	at org.springframework.aop.support.DelegatingIntroductionInterceptor.doProceed(DelegatingIntroductionInterceptor.java:137)
	at org.springframework.aop.support.DelegatingIntroductionInterceptor.invoke(DelegatingIntroductionInterceptor.java:124)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:186)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:763)
	at org.springframework.aop.framework.CglibAopProxy$DynamicAdvisedInterceptor.intercept(CglibAopProxy.java:708)
	at org.mybatis.spring.batch.MyBatisCursorItemReader$$EnhancerBySpringCGLIB$$f534083c.open(<generated>)
	at org.springframework.batch.item.support.CompositeItemStream.open(CompositeItemStream.java:104)
	at org.springframework.batch.core.step.item.ChunkMonitor.open(ChunkMonitor.java:114)
	at org.springframework.batch.item.support.CompositeItemStream.open(CompositeItemStream.java:104)
	at org.springframework.batch.core.step.tasklet.TaskletStep.open(TaskletStep.java:311)
	at org.springframework.batch.core.step.AbstractStep.execute(AbstractStep.java:205)
	at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at java.base/jdk.internal.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.base/java.lang.reflect.Method.invoke(Method.java:566)
	at org.springframework.aop.support.AopUtils.invokeJoinpointUsingReflection(AopUtils.java:344)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.invokeJoinpoint(ReflectiveMethodInvocation.java:198)
	at org.springframework.aop.fram', '2023-08-30 01:35:52.615000'),
        (223, 3, 'sendFailIssueRankCouponStep', 149, '2023-08-30 01:35:53.026000', '2023-08-30 01:35:54.530000', 'FAILED', 1, 0, 0, 0, 0, 0, 0, 0, 'FAILED', '', '2023-08-30 01:35:54.556000'),
        (224, 3, '등급 이름들 가져오기', 151, '2023-08-30 01:36:00.899000', '2023-08-30 01:36:01.261000', 'COMPLETED', 1, 4, 0, 4, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-30 01:36:01.289000'),
        (225, 5, '등급 재산정', 151, '2023-08-30 01:36:01.762000', null, 'STARTED', 4, 38, 0, 38, 0, 0, 0, 0, 'EXECUTING', '', '2023-08-30 01:36:02.411000'),
        (226, 4, '생일 쿠폰 정보 가져오기', 152, '2023-08-30 01:36:42.155000', '2023-08-30 01:36:42.580000', 'COMPLETED', 2, 1, 0, 1, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-30 01:36:42.605000'),
        (227, 3, '생일쿠폰 발급', 152, '2023-08-30 01:36:43.090000', '2023-08-30 01:36:43.429000', 'COMPLETED', 1, 0, 0, 0, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-30 01:36:43.450000'),
        (228, 3, '생일 쿠폰 발급 완료', 152, '2023-08-30 01:36:43.940000', '2023-08-30 01:36:44.251000', 'COMPLETED', 1, 0, 0, 0, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-30 01:36:44.274000'),
        (229, 3, '등급 이름들 가져오기', 153, '2023-08-30 01:36:45.472000', '2023-08-30 01:36:45.879000', 'COMPLETED', 1, 4, 0, 4, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-30 01:36:45.904000'),
        (230, 6, '등급 재산정', 153, '2023-08-30 01:36:46.429000', '2023-08-30 01:36:47.257000', 'COMPLETED', 4, 38, 0, 38, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-30 01:36:47.293000'),
        (231, 3, '등급쿠폰 발급', 153, '2023-08-30 01:36:47.747000', '2023-08-30 01:36:47.917000', 'ABANDONED', 0, 0, 0, 0, 0, 0, 0, 0, 'FAILED', 'org.springframework.batch.item.ItemStreamException: Failed to initialize the reader
	at org.springframework.batch.item.support.AbstractItemCountingItemStreamItemReader.open(AbstractItemCountingItemStreamItemReader.java:153)
	at org.springframework.batch.item.support.AbstractItemCountingItemStreamItemReader$$FastClassBySpringCGLIB$$ebb633d0.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.invokeJoinpoint(CglibAopProxy.java:793)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:163)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:763)
	at org.springframework.aop.support.DelegatingIntroductionInterceptor.doProceed(DelegatingIntroductionInterceptor.java:137)
	at org.springframework.aop.support.DelegatingIntroductionInterceptor.invoke(DelegatingIntroductionInterceptor.java:124)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:186)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:763)
	at org.springframework.aop.framework.CglibAopProxy$DynamicAdvisedInterceptor.intercept(CglibAopProxy.java:708)
	at org.mybatis.spring.batch.MyBatisCursorItemReader$$EnhancerBySpringCGLIB$$61ad9ae5.open(<generated>)
	at org.springframework.batch.item.support.CompositeItemStream.open(CompositeItemStream.java:104)
	at org.springframework.batch.core.step.item.ChunkMonitor.open(ChunkMonitor.java:114)
	at org.springframework.batch.item.support.CompositeItemStream.open(CompositeItemStream.java:104)
	at org.springframework.batch.core.step.tasklet.TaskletStep.open(TaskletStep.java:311)
	at org.springframework.batch.core.step.AbstractStep.execute(AbstractStep.java:205)
	at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at java.base/jdk.internal.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.base/java.lang.reflect.Method.invoke(Method.java:566)
	at org.springframework.aop.support.AopUtils.invokeJoinpointUsingReflection(AopUtils.java:344)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.invokeJoinpoint(ReflectiveMethodInvocation.java:198)
	at org.springframework.aop.fram', '2023-08-30 01:36:48.079000'),
        (232, 1, 'sendFailIssueRankCouponStep', 153, '2023-08-30 01:36:48.499000', null, 'STARTED', 0, 0, 0, 0, 0, 0, 0, 0, 'EXECUTING', '', '2023-08-30 01:36:48.527000'),
        (233, 4, '생일 쿠폰 정보 가져오기', 154, '2023-08-30 01:38:25.049000', '2023-08-30 01:38:25.495000', 'COMPLETED', 2, 1, 0, 1, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-30 01:38:25.518000'),
        (234, 3, '생일쿠폰 발급', 154, '2023-08-30 01:38:26.023000', '2023-08-30 01:38:26.391000', 'COMPLETED', 1, 0, 0, 0, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-30 01:38:26.426000'),
        (235, 3, '생일 쿠폰 발급 완료', 154, '2023-08-30 01:38:26.913000', '2023-08-30 01:38:27.204000', 'COMPLETED', 1, 0, 0, 0, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-30 01:38:27.230000'),
        (236, 3, '등급 이름들 가져오기', 155, '2023-08-30 01:38:28.360000', '2023-08-30 01:38:28.691000', 'COMPLETED', 1, 4, 0, 4, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-30 01:38:28.718000'),
        (237, 6, '등급 재산정', 155, '2023-08-30 01:38:29.237000', '2023-08-30 01:38:30.069000', 'COMPLETED', 4, 38, 0, 38, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-30 01:38:30.099000'),
        (238, 3, '등급쿠폰 발급', 155, '2023-08-30 01:38:30.565000', '2023-08-30 01:38:30.744000', 'ABANDONED', 0, 0, 0, 0, 0, 0, 0, 0, 'FAILED', 'org.springframework.batch.item.ItemStreamException: Failed to initialize the reader
	at org.springframework.batch.item.support.AbstractItemCountingItemStreamItemReader.open(AbstractItemCountingItemStreamItemReader.java:153)
	at org.springframework.batch.item.support.AbstractItemCountingItemStreamItemReader$$FastClassBySpringCGLIB$$ebb633d0.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.invokeJoinpoint(CglibAopProxy.java:793)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:163)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:763)
	at org.springframework.aop.support.DelegatingIntroductionInterceptor.doProceed(DelegatingIntroductionInterceptor.java:137)
	at org.springframework.aop.support.DelegatingIntroductionInterceptor.invoke(DelegatingIntroductionInterceptor.java:124)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:186)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:763)
	at org.springframework.aop.framework.CglibAopProxy$DynamicAdvisedInterceptor.intercept(CglibAopProxy.java:708)
	at org.mybatis.spring.batch.MyBatisCursorItemReader$$EnhancerBySpringCGLIB$$61ad9ae5.open(<generated>)
	at org.springframework.batch.item.support.CompositeItemStream.open(CompositeItemStream.java:104)
	at org.springframework.batch.core.step.item.ChunkMonitor.open(ChunkMonitor.java:114)
	at org.springframework.batch.item.support.CompositeItemStream.open(CompositeItemStream.java:104)
	at org.springframework.batch.core.step.tasklet.TaskletStep.open(TaskletStep.java:311)
	at org.springframework.batch.core.step.AbstractStep.execute(AbstractStep.java:205)
	at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at java.base/jdk.internal.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.base/java.lang.reflect.Method.invoke(Method.java:566)
	at org.springframework.aop.support.AopUtils.invokeJoinpointUsingReflection(AopUtils.java:344)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.invokeJoinpoint(ReflectiveMethodInvocation.java:198)
	at org.springframework.aop.fram', '2023-08-30 01:38:30.920000'),
        (239, 3, 'sendFailIssueRankCouponStep', 155, '2023-08-30 01:38:31.340000', '2023-08-30 01:38:32.737000', 'FAILED', 1, 0, 0, 0, 0, 0, 0, 0, 'FAILED', '', '2023-08-30 01:38:32.768000'),
        (240, 4, '생일 쿠폰 정보 가져오기', 157, '2023-08-30 01:40:06.407000', '2023-08-30 01:40:06.937000', 'COMPLETED', 2, 1, 0, 1, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-30 01:40:06.959000'),
        (241, 3, '생일쿠폰 발급', 157, '2023-08-30 01:40:07.459000', '2023-08-30 01:40:07.793000', 'COMPLETED', 1, 0, 0, 0, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-30 01:40:07.817000'),
        (242, 3, '생일 쿠폰 발급 완료', 157, '2023-08-30 01:40:08.280000', '2023-08-30 01:40:08.581000', 'COMPLETED', 1, 0, 0, 0, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-30 01:40:08.614000'),
        (243, 3, '등급 이름들 가져오기', 158, '2023-08-30 01:40:09.689000', '2023-08-30 01:40:10.022000', 'COMPLETED', 1, 4, 0, 4, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-30 01:40:10.047000'),
        (244, 6, '등급 재산정', 158, '2023-08-30 01:40:10.515000', '2023-08-30 01:40:11.346000', 'COMPLETED', 4, 38, 0, 38, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-30 01:40:11.372000'),
        (245, 3, '등급쿠폰 발급', 158, '2023-08-30 01:40:11.830000', '2023-08-30 01:40:11.996000', 'ABANDONED', 0, 0, 0, 0, 0, 0, 0, 0, 'FAILED', 'org.springframework.batch.item.ItemStreamException: Failed to initialize the reader
	at org.springframework.batch.item.support.AbstractItemCountingItemStreamItemReader.open(AbstractItemCountingItemStreamItemReader.java:153)
	at org.springframework.batch.item.support.AbstractItemCountingItemStreamItemReader$$FastClassBySpringCGLIB$$ebb633d0.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.invokeJoinpoint(CglibAopProxy.java:793)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:163)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:763)
	at org.springframework.aop.support.DelegatingIntroductionInterceptor.doProceed(DelegatingIntroductionInterceptor.java:137)
	at org.springframework.aop.support.DelegatingIntroductionInterceptor.invoke(DelegatingIntroductionInterceptor.java:124)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:186)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:763)
	at org.springframework.aop.framework.CglibAopProxy$DynamicAdvisedInterceptor.intercept(CglibAopProxy.java:708)
	at org.mybatis.spring.batch.MyBatisCursorItemReader$$EnhancerBySpringCGLIB$$f534083c.open(<generated>)
	at org.springframework.batch.item.support.CompositeItemStream.open(CompositeItemStream.java:104)
	at org.springframework.batch.core.step.item.ChunkMonitor.open(ChunkMonitor.java:114)
	at org.springframework.batch.item.support.CompositeItemStream.open(CompositeItemStream.java:104)
	at org.springframework.batch.core.step.tasklet.TaskletStep.open(TaskletStep.java:311)
	at org.springframework.batch.core.step.AbstractStep.execute(AbstractStep.java:205)
	at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at java.base/jdk.internal.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.base/java.lang.reflect.Method.invoke(Method.java:566)
	at org.springframework.aop.support.AopUtils.invokeJoinpointUsingReflection(AopUtils.java:344)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.invokeJoinpoint(ReflectiveMethodInvocation.java:198)
	at org.springframework.aop.fram', '2023-08-30 01:40:12.145000'),
        (246, 3, 'sendFailIssueRankCouponStep', 158, '2023-08-30 01:40:12.566000', '2023-08-30 01:40:14.059000', 'FAILED', 1, 0, 0, 0, 0, 0, 0, 0, 'FAILED', '', '2023-08-30 01:40:14.085000'),
        (247, 3, '등급 이름들 가져오기', 159, '2023-08-30 01:41:01.089000', '2023-08-30 01:41:01.447000', 'COMPLETED', 1, 4, 0, 4, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-30 01:41:01.471000'),
        (248, 6, '등급 재산정', 159, '2023-08-30 01:41:01.962000', '2023-08-30 01:41:02.780000', 'COMPLETED', 4, 38, 0, 38, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-30 01:41:02.806000'),
        (249, 3, '등급쿠폰 발급', 159, '2023-08-30 01:41:03.282000', '2023-08-30 01:41:03.464000', 'ABANDONED', 0, 0, 0, 0, 0, 0, 0, 0, 'FAILED', 'org.springframework.batch.item.ItemStreamException: Failed to initialize the reader
	at org.springframework.batch.item.support.AbstractItemCountingItemStreamItemReader.open(AbstractItemCountingItemStreamItemReader.java:153)
	at org.springframework.batch.item.support.AbstractItemCountingItemStreamItemReader$$FastClassBySpringCGLIB$$ebb633d0.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.invokeJoinpoint(CglibAopProxy.java:793)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:163)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:763)
	at org.springframework.aop.support.DelegatingIntroductionInterceptor.doProceed(DelegatingIntroductionInterceptor.java:137)
	at org.springframework.aop.support.DelegatingIntroductionInterceptor.invoke(DelegatingIntroductionInterceptor.java:124)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:186)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:763)
	at org.springframework.aop.framework.CglibAopProxy$DynamicAdvisedInterceptor.intercept(CglibAopProxy.java:708)
	at org.mybatis.spring.batch.MyBatisCursorItemReader$$EnhancerBySpringCGLIB$$bbd32a44.open(<generated>)
	at org.springframework.batch.item.support.CompositeItemStream.open(CompositeItemStream.java:104)
	at org.springframework.batch.core.step.item.ChunkMonitor.open(ChunkMonitor.java:114)
	at org.springframework.batch.item.support.CompositeItemStream.open(CompositeItemStream.java:104)
	at org.springframework.batch.core.step.tasklet.TaskletStep.open(TaskletStep.java:311)
	at org.springframework.batch.core.step.AbstractStep.execute(AbstractStep.java:205)
	at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at java.base/jdk.internal.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.base/java.lang.reflect.Method.invoke(Method.java:566)
	at org.springframework.aop.support.AopUtils.invokeJoinpointUsingReflection(AopUtils.java:344)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.invokeJoinpoint(ReflectiveMethodInvocation.java:198)
	at org.springframework.aop.fram', '2023-08-30 01:41:03.624000'),
        (250, 3, 'sendFailIssueRankCouponStep', 159, '2023-08-30 01:41:04.028000', '2023-08-30 01:41:05.392000', 'FAILED', 1, 0, 0, 0, 0, 0, 0, 0, 'FAILED', '', '2023-08-30 01:41:05.417000'),
        (251, 3, '등급 이름들 가져오기', 160, '2023-08-30 01:48:01.161000', '2023-08-30 01:48:01.542000', 'COMPLETED', 1, 4, 0, 4, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-30 01:48:01.565000'),
        (252, 6, '등급 재산정', 160, '2023-08-30 01:48:02.074000', '2023-08-30 01:48:02.915000', 'COMPLETED', 4, 38, 0, 38, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-30 01:48:02.938000'),
        (253, 3, '등급쿠폰 발급', 160, '2023-08-30 01:48:03.413000', '2023-08-30 01:48:03.597000', 'ABANDONED', 0, 0, 0, 0, 0, 0, 0, 0, 'FAILED', 'org.springframework.batch.item.ItemStreamException: Failed to initialize the reader
	at org.springframework.batch.item.support.AbstractItemCountingItemStreamItemReader.open(AbstractItemCountingItemStreamItemReader.java:153)
	at org.springframework.batch.item.support.AbstractItemCountingItemStreamItemReader$$FastClassBySpringCGLIB$$ebb633d0.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.invokeJoinpoint(CglibAopProxy.java:793)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:163)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:763)
	at org.springframework.aop.support.DelegatingIntroductionInterceptor.doProceed(DelegatingIntroductionInterceptor.java:137)
	at org.springframework.aop.support.DelegatingIntroductionInterceptor.invoke(DelegatingIntroductionInterceptor.java:124)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:186)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:763)
	at org.springframework.aop.framework.CglibAopProxy$DynamicAdvisedInterceptor.intercept(CglibAopProxy.java:708)
	at org.mybatis.spring.batch.MyBatisCursorItemReader$$EnhancerBySpringCGLIB$$efa7bfd7.open(<generated>)
	at org.springframework.batch.item.support.CompositeItemStream.open(CompositeItemStream.java:104)
	at org.springframework.batch.core.step.item.ChunkMonitor.open(ChunkMonitor.java:114)
	at org.springframework.batch.item.support.CompositeItemStream.open(CompositeItemStream.java:104)
	at org.springframework.batch.core.step.tasklet.TaskletStep.open(TaskletStep.java:311)
	at org.springframework.batch.core.step.AbstractStep.execute(AbstractStep.java:205)
	at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at java.base/jdk.internal.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.base/java.lang.reflect.Method.invoke(Method.java:566)
	at org.springframework.aop.support.AopUtils.invokeJoinpointUsingReflection(AopUtils.java:344)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.invokeJoinpoint(ReflectiveMethodInvocation.java:198)
	at org.springframework.aop.fram', '2023-08-30 01:48:03.755000'),
        (254, 3, 'sendFailIssueRankCouponStep', 160, '2023-08-30 01:48:04.164000', '2023-08-30 01:48:05.729000', 'FAILED', 1, 0, 0, 0, 0, 0, 0, 0, 'FAILED', '', '2023-08-30 01:48:05.754000'),
        (255, 3, '등급 이름들 가져오기', 161, '2023-08-30 01:56:01.070000', '2023-08-30 01:56:01.412000', 'COMPLETED', 1, 4, 0, 4, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-30 01:56:01.437000'),
        (256, 6, '등급 재산정', 161, '2023-08-30 01:56:01.927000', '2023-08-30 01:56:02.761000', 'COMPLETED', 4, 38, 0, 38, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-30 01:56:02.784000'),
        (257, 3, '등급쿠폰 발급', 161, '2023-08-30 01:56:03.277000', '2023-08-30 01:56:03.433000', 'ABANDONED', 0, 0, 0, 0, 0, 0, 0, 0, 'FAILED', 'org.springframework.batch.item.ItemStreamException: Failed to initialize the reader
	at org.springframework.batch.item.support.AbstractItemCountingItemStreamItemReader.open(AbstractItemCountingItemStreamItemReader.java:153)
	at org.springframework.batch.item.support.AbstractItemCountingItemStreamItemReader$$FastClassBySpringCGLIB$$ebb633d0.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.invokeJoinpoint(CglibAopProxy.java:793)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:163)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:763)
	at org.springframework.aop.support.DelegatingIntroductionInterceptor.doProceed(DelegatingIntroductionInterceptor.java:137)
	at org.springframework.aop.support.DelegatingIntroductionInterceptor.invoke(DelegatingIntroductionInterceptor.java:124)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:186)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:763)
	at org.springframework.aop.framework.CglibAopProxy$DynamicAdvisedInterceptor.intercept(CglibAopProxy.java:708)
	at org.mybatis.spring.batch.MyBatisCursorItemReader$$EnhancerBySpringCGLIB$$a6ec2860.open(<generated>)
	at org.springframework.batch.item.support.CompositeItemStream.open(CompositeItemStream.java:104)
	at org.springframework.batch.core.step.item.ChunkMonitor.open(ChunkMonitor.java:114)
	at org.springframework.batch.item.support.CompositeItemStream.open(CompositeItemStream.java:104)
	at org.springframework.batch.core.step.tasklet.TaskletStep.open(TaskletStep.java:311)
	at org.springframework.batch.core.step.AbstractStep.execute(AbstractStep.java:205)
	at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at java.base/jdk.internal.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.base/java.lang.reflect.Method.invoke(Method.java:566)
	at org.springframework.aop.support.AopUtils.invokeJoinpointUsingReflection(AopUtils.java:344)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.invokeJoinpoint(ReflectiveMethodInvocation.java:198)
	at org.springframework.aop.fram', '2023-08-30 01:56:03.609000'),
        (258, 3, 'sendFailIssueRankCouponStep', 161, '2023-08-30 01:56:04.025000', '2023-08-30 01:56:05.558000', 'FAILED', 1, 0, 0, 0, 0, 0, 0, 0, 'FAILED', '', '2023-08-30 01:56:05.581000'),
        (259, 3, '등급 이름들 가져오기', 162, '2023-08-30 01:59:01.054000', '2023-08-30 01:59:01.401000', 'COMPLETED', 1, 4, 0, 4, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-30 01:59:01.434000'),
        (260, 6, '등급 재산정', 162, '2023-08-30 01:59:01.902000', '2023-08-30 01:59:02.724000', 'COMPLETED', 4, 38, 0, 38, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-30 01:59:02.747000'),
        (261, 3, '등급쿠폰 발급', 162, '2023-08-30 01:59:03.193000', '2023-08-30 01:59:03.359000', 'ABANDONED', 0, 0, 0, 0, 0, 0, 0, 0, 'FAILED', 'org.springframework.batch.item.ItemStreamException: Failed to initialize the reader
	at org.springframework.batch.item.support.AbstractItemCountingItemStreamItemReader.open(AbstractItemCountingItemStreamItemReader.java:153)
	at org.springframework.batch.item.support.AbstractItemCountingItemStreamItemReader$$FastClassBySpringCGLIB$$ebb633d0.invoke(<generated>)
	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:218)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.invokeJoinpoint(CglibAopProxy.java:793)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:163)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:763)
	at org.springframework.aop.support.DelegatingIntroductionInterceptor.doProceed(DelegatingIntroductionInterceptor.java:137)
	at org.springframework.aop.support.DelegatingIntroductionInterceptor.invoke(DelegatingIntroductionInterceptor.java:124)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:186)
	at org.springframework.aop.framework.CglibAopProxy$CglibMethodInvocation.proceed(CglibAopProxy.java:763)
	at org.springframework.aop.framework.CglibAopProxy$DynamicAdvisedInterceptor.intercept(CglibAopProxy.java:708)
	at org.mybatis.spring.batch.MyBatisCursorItemReader$$EnhancerBySpringCGLIB$$61168550.open(<generated>)
	at org.springframework.batch.item.support.CompositeItemStream.open(CompositeItemStream.java:104)
	at org.springframework.batch.core.step.item.ChunkMonitor.open(ChunkMonitor.java:114)
	at org.springframework.batch.item.support.CompositeItemStream.open(CompositeItemStream.java:104)
	at org.springframework.batch.core.step.tasklet.TaskletStep.open(TaskletStep.java:311)
	at org.springframework.batch.core.step.AbstractStep.execute(AbstractStep.java:205)
	at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
	at java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
	at java.base/jdk.internal.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
	at java.base/java.lang.reflect.Method.invoke(Method.java:566)
	at org.springframework.aop.support.AopUtils.invokeJoinpointUsingReflection(AopUtils.java:344)
	at org.springframework.aop.framework.ReflectiveMethodInvocation.invokeJoinpoint(ReflectiveMethodInvocation.java:198)
	at org.springframework.aop.fram', '2023-08-30 01:59:03.516000'),
        (262, 3, 'sendFailIssueRankCouponStep', 162, '2023-08-30 01:59:03.892000', '2023-08-30 01:59:05.257000', 'FAILED', 1, 0, 0, 0, 0, 0, 0, 0, 'FAILED', '', '2023-08-30 01:59:05.280000'),
        (263, 3, '등급 이름들 가져오기', 163, '2023-08-30 02:03:01.026000', '2023-08-30 02:03:01.357000', 'COMPLETED', 1, 4, 0, 4, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-30 02:03:01.379000'),
        (264, 174, '등급 재산정', 163, '2023-08-30 02:03:01.843000', null, 'STOPPED', 173, 1730, 0, 1730, 0, 0, 0, 0, 'EXECUTING', '', '2023-08-30 02:03:26.847000'),
        (265, 3, '등급 이름들 가져오기', 164, '2023-08-30 02:05:00.995000', '2023-08-30 02:05:01.348000', 'COMPLETED', 1, 4, 0, 4, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-30 02:05:01.374000'),
        (266, 108, '등급 재산정', 164, '2023-08-30 02:05:01.811000', null, 'STARTED', 107, 1070, 0, 1070, 0, 0, 0, 0, 'EXECUTING', '', '2023-08-30 02:05:17.480000'),
        (267, 3, '등급 이름들 가져오기', 165, '2023-08-30 02:08:01.095000', '2023-08-30 02:08:01.448000', 'COMPLETED', 1, 4, 0, 4, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-30 02:08:01.468000'),
        (268, 6, '등급 재산정', 165, '2023-08-30 02:08:01.887000', '2023-08-30 02:08:02.653000', 'COMPLETED', 4, 38, 0, 38, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-30 02:08:02.676000'),
        (269, 6, '등급쿠폰 발급', 165, '2023-08-30 02:08:03.090000', '2023-08-30 02:08:03.866000', 'COMPLETED', 4, 39, 0, 39, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-30 02:08:03.889000'),
        (270, 3, '등급 이름들 가져오기', 166, '2023-08-30 02:11:01.029000', '2023-08-30 02:11:01.377000', 'COMPLETED', 1, 4, 0, 4, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-30 02:11:01.400000'),
        (271, 6, '등급 재산정', 166, '2023-08-30 02:11:01.811000', '2023-08-30 02:11:02.566000', 'COMPLETED', 4, 38, 0, 38, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-30 02:11:02.589000'),
        (272, 6, '등급쿠폰 발급', 166, '2023-08-30 02:11:02.982000', '2023-08-30 02:11:03.846000', 'COMPLETED', 4, 36, 0, 36, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-30 02:11:03.869000'),
        (273, 3, '등급 이름들 가져오기', 167, '2023-08-30 02:15:01.029000', '2023-08-30 02:15:01.365000', 'COMPLETED', 1, 4, 0, 4, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-30 02:15:01.386000'),
        (274, 6, '등급 재산정', 167, '2023-08-30 02:15:01.858000', '2023-08-30 02:15:02.673000', 'COMPLETED', 4, 38, 0, 38, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-30 02:15:02.702000'),
        (275, 6, '등급쿠폰 발급', 167, '2023-08-30 02:15:03.183000', '2023-08-30 02:15:03.979000', 'COMPLETED', 4, 38, 0, 38, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-30 02:15:03.999000'),
        (276, 3, 'rankCouponIssueStep', 167, '2023-08-30 02:15:04.479000', '2023-08-30 02:15:04.793000', 'COMPLETED', 1, 0, 0, 0, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-30 02:15:04.834000'),
        (277, 4, '생일 쿠폰 정보 가져오기', 168, '2023-08-30 18:57:01.569000', '2023-08-30 18:57:02.248000', 'COMPLETED', 2, 1, 0, 1, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-30 18:57:02.288000'),
        (278, 4, '생일쿠폰 발급', 168, '2023-08-30 18:57:03.028000', '2023-08-30 18:57:03.778000', 'COMPLETED', 2, 11, 0, 11, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-30 18:57:03.818000'),
        (279, 3, '생일 쿠폰 발급 완료', 168, '2023-08-30 18:57:04.508000', '2023-08-30 18:57:04.969000', 'COMPLETED', 1, 0, 0, 0, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-30 18:57:05.008000'),
        (280, 4, '생일 쿠폰 정보 가져오기', 169, '2023-08-30 18:59:01.561000', '2023-08-30 18:59:02.260000', 'COMPLETED', 2, 1, 0, 1, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-30 18:59:02.300000'),
        (281, 4, '생일 쿠폰 정보 가져오기', 170, '2023-08-30 19:07:01.430000', '2023-08-30 19:07:02.090000', 'COMPLETED', 2, 1, 0, 1, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-30 19:07:02.130000'),
        (282, 3, '생일쿠폰 발급', 170, '2023-08-30 19:07:02.860000', '2023-08-30 19:07:03.400000', 'COMPLETED', 1, 1, 0, 1, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-30 19:07:03.440000'),
        (283, 3, '생일 쿠폰 발급 완료', 170, '2023-08-30 19:07:04.160000', '2023-08-30 19:07:04.621000', 'COMPLETED', 1, 0, 0, 0, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-30 19:07:04.659000'),
        (284, 3, '등급 이름들 가져오기', 171, '2023-08-30 19:33:01.602000', '2023-08-30 19:33:02.133000', 'COMPLETED', 1, 4, 0, 4, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-30 19:33:02.172000'),
        (285, 6, '등급 재산정', 171, '2023-08-30 19:33:02.993000', '2023-08-30 19:33:04.192000', 'COMPLETED', 4, 38, 0, 38, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-30 19:33:04.231000'),
        (286, 6, '등급쿠폰 발급', 171, '2023-08-30 19:33:04.952000', '2023-08-30 19:33:06.351000', 'COMPLETED', 4, 38, 0, 38, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-30 19:33:06.391000'),
        (287, 3, 'rankCouponIssueStep', 171, '2023-08-30 19:33:07.112000', '2023-08-30 19:33:07.572000', 'COMPLETED', 1, 0, 0, 0, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-30 19:33:07.612000'),
        (288, 3, '등급 이름들 가져오기', 172, '2023-08-30 20:16:01.476000', '2023-08-30 20:16:01.976000', 'COMPLETED', 1, 4, 0, 4, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-30 20:16:02.016000'),
        (289, 6, '등급 재산정', 172, '2023-08-30 20:16:02.726000', '2023-08-30 20:16:03.836000', 'COMPLETED', 4, 38, 0, 38, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-30 20:16:03.876000'),
        (290, 6, '등급쿠폰 발급', 172, '2023-08-30 20:16:04.597000', '2023-08-30 20:16:06.007000', 'COMPLETED', 4, 38, 0, 38, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-30 20:16:06.046000'),
        (291, 3, 'rankCouponIssueStep', 172, '2023-08-30 20:16:06.766000', '2023-08-30 20:16:07.237000', 'COMPLETED', 1, 0, 0, 0, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-30 20:16:07.276000'),
        (292, 3, '등급 이름들 가져오기', 173, '2023-08-31 06:09:01.580000', '2023-08-31 06:09:02.129000', 'COMPLETED', 1, 4, 0, 4, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-31 06:09:02.168000'),
        (293, 7, '등급 재산정', 173, '2023-08-31 06:09:02.889000', '2023-08-31 06:09:08.248000', 'COMPLETED', 5, 20146, 0, 20146, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-31 06:09:08.288000'),
        (294, 7, '등급쿠폰 발급', 173, '2023-08-31 06:09:08.989000', '2023-08-31 06:09:12.358000', 'COMPLETED', 5, 20146, 0, 20146, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-31 06:09:12.398000'),
        (295, 3, 'rankCouponIssueStep', 173, '2023-08-31 06:09:13.118000', '2023-08-31 06:09:13.569000', 'COMPLETED', 1, 0, 0, 0, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-31 06:09:13.609000'),
        (296, 3, '등급 이름들 가져오기', 174, '2023-08-31 06:16:01.554000', '2023-08-31 06:16:02.074000', 'COMPLETED', 1, 4, 0, 4, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-31 06:16:02.113000'),
        (297, 7, '등급 재산정', 174, '2023-08-31 06:16:02.813000', '2023-08-31 06:16:07.043000', 'COMPLETED', 5, 20146, 0, 20146, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-31 06:16:07.084000'),
        (298, 7, '등급쿠폰 발급', 174, '2023-08-31 06:16:07.824000', '2023-08-31 06:16:10.993000', 'COMPLETED', 5, 20146, 0, 20146, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-31 06:16:11.033000'),
        (299, 3, 'rankCouponIssueStep', 174, '2023-08-31 06:16:11.753000', '2023-08-31 06:16:12.214000', 'COMPLETED', 1, 0, 0, 0, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-31 06:16:12.254000'),
        (300, 3, '등급 이름들 가져오기', 175, '2023-08-31 06:22:01.578000', '2023-08-31 06:22:02.107000', 'COMPLETED', 1, 4, 0, 4, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-31 06:22:02.145000'),
        (301, 7, '등급 재산정', 175, '2023-08-31 06:22:02.877000', '2023-08-31 06:22:07.036000', 'COMPLETED', 5, 20146, 0, 20146, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-31 06:22:07.075000'),
        (302, 7, '등급쿠폰 발급', 175, '2023-08-31 06:22:07.806000', '2023-08-31 06:22:10.765000', 'COMPLETED', 5, 20146, 0, 20146, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-31 06:22:10.805000'),
        (303, 3, 'rankCouponIssueStep', 175, '2023-08-31 06:22:11.505000', '2023-08-31 06:22:11.995000', 'COMPLETED', 1, 0, 0, 0, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-31 06:22:12.036000'),
        (304, 3, '등급 이름들 가져오기', 176, '2023-08-31 06:39:01.602000', '2023-08-31 06:39:02.102000', 'COMPLETED', 1, 4, 0, 4, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-31 06:39:02.141000'),
        (305, 7, '등급 재산정', 176, '2023-08-31 06:39:02.882000', '2023-08-31 06:39:08.081000', 'COMPLETED', 5, 20146, 0, 20146, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-31 06:39:08.111000'),
        (306, 7, '등급쿠폰 발급', 176, '2023-08-31 06:39:08.811000', '2023-08-31 06:39:11.821000', 'COMPLETED', 5, 20146, 0, 20146, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-31 06:39:11.861000'),
        (307, 3, 'rankCouponIssueStep', 176, '2023-08-31 06:39:12.592000', '2023-08-31 06:39:13.031000', 'COMPLETED', 1, 0, 0, 0, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-31 06:39:13.061000'),
        (308, 3, '등급 이름들 가져오기', 177, '2023-08-31 06:59:01.538000', '2023-08-31 06:59:02.027000', 'COMPLETED', 1, 4, 0, 4, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-31 06:59:02.047000'),
        (309, 17, '등급 재산정', 177, '2023-08-31 06:59:02.737000', '2023-08-31 06:59:19.977000', 'COMPLETED', 15, 70146, 0, 70146, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-31 06:59:20.017000'),
        (310, 10, '등급쿠폰 발급', 177, '2023-08-31 06:59:20.797000', '2023-08-31 06:59:28.327000', 'COMPLETED', 8, 70146, 0, 70146, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-31 06:59:28.367000'),
        (311, 3, 'rankCouponIssueStep', 177, '2023-08-31 06:59:29.077000', '2023-08-31 06:59:29.477000', 'COMPLETED', 1, 0, 0, 0, 0, 0, 0, 0, 'COMPLETED', '', '2023-08-31 06:59:29.516000'),
        (312, 3, '휴면될 회원리스트 가져오기', 178, '2023-08-31 14:12:00.391000', '2023-08-31 14:12:00.728000', 'ABANDONED', 0, 7, 0, 0, 0, 0, 0, 2, 'FAILED', 'org.springframework.retry.ExhaustedRetryException: Retry exhausted after last attempt in recovery path, but exception is not skippable.; nested exception is org.springframework.dao.DataIntegrityViolationException: store.cookshoong.www.cookshoongspringbatch.status.mapper.StatusMapper.updateAccounts (batch index #1) failed. Cause: java.sql.BatchUpdateException: Cannot add or update a child row: a foreign key constraint fails (`cookshoong_shop_dev`.`accounts`, CONSTRAINT `FK_status_TO_accounts_1` FOREIGN KEY (`status_code`) REFERENCES `account_status` (`status_code`))
; Cannot add or update a child row: a foreign key constraint fails (`cookshoong_shop_dev`.`accounts`, CONSTRAINT `FK_status_TO_accounts_1` FOREIGN KEY (`status_code`) REFERENCES `account_status` (`status_code`)); nested exception is java.sql.BatchUpdateException: Cannot add or update a child row: a foreign key constraint fails (`cookshoong_shop_dev`.`accounts`, CONSTRAINT `FK_status_TO_accounts_1` FOREIGN KEY (`status_code`) REFERENCES `account_status` (`status_code`))
	at org.springframework.batch.core.step.item.FaultTolerantChunkProcessor$5.recover(FaultTolerantChunkProcessor.java:429)
	at org.springframework.retry.support.RetryTemplate.handleRetryExhausted(RetryTemplate.java:539)
	at org.springframework.retry.support.RetryTemplate.doExecute(RetryTemplate.java:387)
	at org.springframework.retry.support.RetryTemplate.execute(RetryTemplate.java:255)
	at org.springframework.batch.core.step.item.BatchRetryTemplate.execute(BatchRetryTemplate.java:217)
	at org.springframework.batch.core.step.item.FaultTolerantChunkProcessor.write(FaultTolerantChunkProcessor.java:444)
	at org.springframework.batch.core.step.item.SimpleChunkProcessor.process(SimpleChunkProcessor.java:217)
	at org.springframework.batch.core.step.item.ChunkOrientedTasklet.execute(ChunkOrientedTasklet.java:77)
	at org.springframework.batch.core.step.tasklet.TaskletStep$ChunkTransactionCallback.doInTransaction(TaskletStep.java:407)
	at org.springframework.batch.core.step.tasklet.TaskletStep$ChunkTransactionCallback.doInTransaction(TaskletStep.java:331)
	at org.springframework.transaction.support.TransactionTemplate.execute(TransactionTemplate.java:140)
	at org.springframework.batch.core.step.tasklet.TaskletStep$2.doInChunkContext(TaskletStep.java:273)
	at org.springframework.batch.core.scope.context.StepContextRepeatCallback.doInIteration(StepContextRepeatCallback.java:82)
	at org.springframework.batch.repeat.support.RepeatTemplate.getNex', '2023-08-31 14:12:00.783000'),
        (313, 3, 'statusChangeFailStep', 178, '2023-08-31 14:12:00.905000', '2023-08-31 14:12:02.184000', 'FAILED', 1, 0, 0, 0, 0, 0, 0, 0, 'FAILED', '', '2023-08-31 14:12:02.192000');