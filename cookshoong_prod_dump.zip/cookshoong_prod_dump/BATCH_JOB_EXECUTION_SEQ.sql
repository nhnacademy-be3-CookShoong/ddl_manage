insert into cookshoong_shop_prod.BATCH_JOB_EXECUTION_SEQ (ID, UNIQUE_KEY)
values  (178, '0');