insert into cookshoong_shop_prod.day_types (day_code, description)
values  ('FRI', '금요일'),
        ('MON', '월요일'),
        ('SAT', '토요일'),
        ('SUN', '일요일'),
        ('THU', '목요일'),
        ('TUE', '화요일'),
        ('WED', '수요일');