insert into cookshoong_shop_prod.cart_detail_menu_options (cart_detail_id, option_id)
values  (357, 1),
        (374, 13),
        (357, 31);