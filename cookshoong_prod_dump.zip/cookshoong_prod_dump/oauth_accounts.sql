insert into cookshoong_shop_prod.oauth_accounts (account_id, oauth_type_id, account_code)
values  (70162, 1, 'a8d0ccf0-c84e-11e7-ad80-941882012e00');