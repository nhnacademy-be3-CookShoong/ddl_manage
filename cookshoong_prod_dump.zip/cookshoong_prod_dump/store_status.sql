insert into cookshoong_shop_prod.store_status (store_status_code, description)
values  ('BREAK_TIME', '휴식중'),
        ('CLOSE', '준비중'),
        ('OPEN', '영업중'),
        ('OUTED', '폐업');