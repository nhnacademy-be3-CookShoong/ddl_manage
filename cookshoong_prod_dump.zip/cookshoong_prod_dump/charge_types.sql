insert into cookshoong_shop_prod.charge_types (charge_type_code, name, is_deleted)
values  ('admin', 'admin', 1),
        ('PAYCO', '페이코결제', 0),
        ('TOSS', '토스결제', 0);