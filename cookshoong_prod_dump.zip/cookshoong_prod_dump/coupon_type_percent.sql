insert into cookshoong_shop_prod.coupon_type_percent (coupon_type_id, rate, minimum_order_price, maximum_discount_amount)
values  (2, 10.0, 10000, 30000),
        (6, 10.0, 10000, 5000),
        (7, 50.0, 20000, 20000),
        (8, 20.0, 20000, 10000),
        (10, 20.0, 5000, 10000),
        (12, 11.0, 11111, 20000),
        (14, 25.0, 10000, 20000),
        (19, 20.0, 5000, 15000);