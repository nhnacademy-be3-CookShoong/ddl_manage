insert into cookshoong_shop_prod.coupon_usage_all (coupon_usage_id)
values  (1);