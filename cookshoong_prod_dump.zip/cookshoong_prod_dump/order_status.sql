insert into cookshoong_shop_prod.order_status (order_status_code, description)
values  ('CANCEL', '주문취소'),
        ('COMPLETE', '배달완료'),
        ('COOKING', '조리중'),
        ('CREATE', '생성'),
        ('DELIVER', '배달중'),
        ('FOOD_OUT', '재료소진'),
        ('ORD_FLOOD', '주문폭주'),
        ('PARTIAL', '환불'),
        ('PAY', '주문완료');