insert into cookshoong_shop_prod.review_reply (review_reply_id, review_id, contents, written_at)
values  (2, 27, '<p>주문해주셔서 감사합니다!!</p>', '2023-08-16 16:28:50'),
        (3, 28, '<p>앞으로 더 노력하겠습니다~</p>', '2023-08-16 16:29:00'),
        (4, 27, '<p>다음에 또 주문해주세요~</p>', '2023-08-16 16:40:35');