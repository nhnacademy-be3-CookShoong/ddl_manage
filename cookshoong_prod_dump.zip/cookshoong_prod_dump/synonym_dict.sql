insert into cookshoong_shop_prod.synonym_dict (basic_word_id, synonym_word_id)
values  (1, 2),
        (1, 3),
        (1, 4),
        (1, 5),
        (6, 7),
        (6, 8),
        (6, 9),
        (6, 10),
        (11, 12);