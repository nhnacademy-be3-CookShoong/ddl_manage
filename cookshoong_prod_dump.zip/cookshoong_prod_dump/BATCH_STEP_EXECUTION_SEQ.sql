insert into cookshoong_shop_prod.BATCH_STEP_EXECUTION_SEQ (ID, UNIQUE_KEY)
values  (313, '0');