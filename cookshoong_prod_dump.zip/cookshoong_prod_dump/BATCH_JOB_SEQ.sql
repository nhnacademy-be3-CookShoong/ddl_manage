insert into cookshoong_shop_prod.BATCH_JOB_SEQ (ID, UNIQUE_KEY)
values  (119, '0');