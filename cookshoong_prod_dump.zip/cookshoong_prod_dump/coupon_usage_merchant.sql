insert into cookshoong_shop_prod.coupon_usage_merchant (coupon_usage_id, merchant_id)
values  (5, 1);