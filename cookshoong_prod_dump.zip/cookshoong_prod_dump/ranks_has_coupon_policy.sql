insert into cookshoong_shop_prod.ranks_has_coupon_policy (rank_code, coupon_policy_id)
values  ('LEVEL_1', 40),
        ('LEVEL_2', 41),
        ('LEVEL_3', 42),
        ('LEVEL_4', 43);