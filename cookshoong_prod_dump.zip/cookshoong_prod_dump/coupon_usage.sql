insert into cookshoong_shop_prod.coupon_usage (coupon_usage_id, sub_type)
values  (1, 'ALL'),
        (2, 'STORE'),
        (3, 'STORE'),
        (4, 'STORE'),
        (5, 'MERCHANT'),
        (6, 'STORE'),
        (7, 'STORE'),
        (8, 'STORE');