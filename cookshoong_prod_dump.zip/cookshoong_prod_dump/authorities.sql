insert into cookshoong_shop_prod.authorities (authority_code, description)
values  ('ADMIN', '시스템관리자'),
        ('BUSINESS', '사업자회원'),
        ('CUSTOMER', '일반회원');