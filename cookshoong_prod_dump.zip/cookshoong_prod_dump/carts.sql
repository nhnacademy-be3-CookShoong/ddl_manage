insert into cookshoong_shop_prod.carts (cart_id, account_id, store_id)
values  (0x509EDD45F3F04F5A9025B6B74A449B67, 20, 1),
        (0x611354AEF5B94036A25351CAA9EEC76B, 70157, 2),
        (0xB1E1FAD5D0DE44CC8A8BBE278BDFCFF5, 1, 2);