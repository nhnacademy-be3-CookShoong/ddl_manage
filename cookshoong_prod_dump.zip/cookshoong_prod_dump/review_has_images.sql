insert into cookshoong_shop_prod.review_has_images (review_id, image_id)
values  (27, 254),
        (28, 255),
        (29, 256),
        (35, 381);