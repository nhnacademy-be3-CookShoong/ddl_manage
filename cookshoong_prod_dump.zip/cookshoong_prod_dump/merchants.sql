insert into cookshoong_shop_prod.merchants (merchant_id, name)
values  (1, '네네치킨'),
        (2, '도미노피자'),
        (3, '토마토피자'),
        (4, '원할머니보쌈'),
        (5, '비비큐치킨'),
        (6, '디저트39'),
        (9, '투썸플레이스'),
        (10, '두찜'),
        (11, '족발팩토리');